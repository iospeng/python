from appium import webdriver
import time
import unittest

class android(object):
    desired_caps = {
        "device": "android",
        "platformName": "Android",
        "platformVersion": "8.0.0",
        "deviceName": "HMKNW17923009392",
        "appPackage": "com.vxianjin.gringotts",
        "appActivity": "com.jxmoney.gringotts.ui.main.MainActivity",
        "noReset": "True",
        "unicodeKeyboard" : True,
        "resetKeyboard":True # 隐藏键盘

    }
    driver = webdriver.Remote("http://127.0.0.1:4723/wd/hub", desired_caps)  # 连接Appium
    time.sleep(2)
    driver.find_element_by_id('com.vxianjin.gringotts:id/rb_rent_lend').click()  # 点击还款tab
    time.sleep(2)
    driver.find_element_by_id('com.vxianjin.gringotts:id/tv_login_more').click()  # 点击更多
    time.sleep(2)
    driver.find_element_by_xpath('/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.TextView[2]').click()  # 点击切换用户
    time.sleep(5)
    driver.find_element_by_id('com.vxianjin.gringotts:id/et_phone_number').send_keys('15671278825')  # 输入账号
    time.sleep(2)
    driver.find_element_by_id('com.vxianjin.gringotts:id/tv_next').click()  # 点击下一步
    time.sleep(2)
    driver.find_element_by_id('com.vxianjin.gringotts:id/et_password').send_keys('123456')  # 输入密码
    time.sleep(2)
    driver.find_element_by_id('com.vxianjin.gringotts:id/tv_login').click()  # 点击登陆按钮
