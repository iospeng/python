# -*- coding: utf-8 -*-

# @Time : 2018/12/28 下午3:29

# @Author : 废柴

# @Project: Jx

# @FileName : Jx-01.py

# @Software: PyCharm

# @Desc : ==============================================

# Life is Short I Use Python!!!                      ===

# If this runs wrong,don't ask me,I don't know why;  ===

# If this runs right,thank god,and I don't know why. ===

# Maybe the answer,my friend,is blowing in the wind. ===

# ======================================================

import time
import warnings
import unittest
from TestConfig.settings import *
from Until import logger, Tools
from Config import Login, Sign_out, MyPage, Set_up
from appium import webdriver
from ddt import ddt, data, file_data, unpack
from Config.Base import DesiredCaps

# ---------------------
# 测试数据配置区域开始
# ---------------------

test_data = os.path.join(os.path.dirname(__file__), 'login_test.json').replace('Case', 'Data')
password_data = os.path.join(os.path.dirname(__file__), 'login_password.json').replace('Case', 'Data')
pay_data = os.path.join(os.path.dirname(__file__), 'pay_password.json').replace('Case', 'Data')

# ---------------------
# 配置文件开始区域
# ---------------------

ac = Tools.info()
my = Tools.Tools.element('{}/MyPage.yaml'.format(ac[-1]))
bp = Tools.Tools.element('{}/BorrowPage.yaml'.format(ac[-1]))
ut = Tools.Tools.element('{}/Until.yaml'.format(ac[-1]))

# ---------------------
#  日志配置
# ---------------------

logger = logger.get_logger('login')


# ---------------------
# app启动配置文件
# ---------------------

# ac = Tools.app_config('AppConfig.yml')['MI']


DESIRED_CAPS = DesiredCaps.DesiredCaps(device_id=ac[0], version=ac[1], app_package=ac[2][0], app_activity=ac[2][1])


@ddt
class Jx_1(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        """每执行一个测试用例，初始化一次测试环境"""
        warnings.simplefilter('ignore', ResourceWarning)
        cls.driver = webdriver.Remote('http://127.0.0.1:4723/wd/hub', DESIRED_CAPS.all_config())
        cls.driver.wait_activity('.ui.main.MainActivity', 30)

    def add_img(self):
        self.imgs.append(self.driver.get_screenshot_as_base64())
        return True

    # 测试验证：安卓已经存在的账户--->验证密码
    @file_data(test_data)
    def test_1(self, var):
        # 读取测试密码的验证数据
        pawd = var[0]['info']['data']['pawd']
        # 调用login函数
        Login.login(self.driver, password=pawd)
        # 因安卓屏幕适配问题，导致断言元素被屏幕遮挡，因此需要执行上滑动操作。
        Tools.swipe_up(self.driver, t=500, n=1)

        try:  # 尝试断言我要借款按钮文本
            b = self.driver.find_element_by_id(bp['borrow']['borrow_id']).text
            self.assertEqual('我要借款', b)
            # 若断言正确，则截图并执行 ---> 退出登录 sign_out函数，便于下一用例执行。
            self.add_img()
            self.driver.get_screenshot_as_file(Tools.Tools.cut('test_login') + '.png')
            Tools.is_element(self.driver, element=ut['until']['mine_id'])
            time.sleep(2.0)
            Sign_out.sign_out(self.driver, option=True)
            # 在设置中退出后页面并不会自动跳转至 ---> 借款首页，需要我的页面点击借款按钮
            self.driver.find_element_by_id(ut['until']['borrowd_id']).click()
        except:
            # 若try执行异常, except捕获,断言借享钱包页面--->登录文本
            t1 = Tools.is_toast(self.driver, toast_text='你输入的用户或密码不正确，请重新输入。')
            self.driver.find_element_by_id(ut['jx_wallet']['login_id']).click()
            t2 = Tools.is_toast(self.driver, toast_text='密码必须为6~16字')
            if t1:
                self.assertTrue(t1)   # 断言 t方法的返回值是否为真
            elif t2:
                self.assertTrue(t2)   # 断言 t方法的返回值是否为真

            # 登录失败之后需要回到借款首页继续测试其他情景 ---> 此处执行左返回 或这直接执行self.driver.keyboard(4)
            self.driver.find_element_by_id(ut['until']['return_id']).click()
            time.sleep(1.0)

    # 选择更多 ---> 切换用户
    def test_2(self):
        """验证切换用户功能"""
        item = self.driver.find_element_by_id(bp['borrow']['borrow_id']).text
        """
        若当前状态时登录状态则执行退出登录操作，验证切换功能
        否则进行切换功能验证
        """
        if item == '马上登录':
            for i in range(3):
                time.sleep(1.0)
                Login.change(self.driver, option=i)
                if i in [0, 1]:
                    text = self.driver.find_element_by_id(ut['jx_register']['next_id']).text
                    self.assertEqual('下一步', text, msg='执行了切换用户操作或注册操作')
                    # 注册或切换用户操作后 ---> 此处执行左返回
                    self.driver.find_element_by_id(ut['until']['return_id']).click()
                else:
                    text = self.driver.find_element_by_id(ut['jx_wallet']['login_id']).text
                    self.assertEqual('登录', text, msg='执行了取消操作')
        elif item == '我要借款':
            # 进入登录状态，执行流程测试
            Tools.is_element(self.driver, element=ut['until']['mine_id'])
            time.sleep(2.0)
            Sign_out.sign_out(self.driver, option=True)
            for i in range(3):
                Login.change(self.driver, option=i)
                if i in [0, 1]:
                    text = self.driver.find_element_by_id(ut['jx_register']['next_id']).text
                    self.assertEqual('下一步', text, msg='执行了切换用户操作或注册操作')
                    # 注册或切换用户操作后 ---> 此处执行左返回
                    self.driver.find_element_by_id(ut['until']['return_id']).click()
                else:
                    text = self.driver.find_element_by_id(ut['jx_wallet']['login_id']).text
                    self.assertEqual('登录', text, msg='执行了取消操作')

    # 跳转借款首页函数 ---> 过渡函数
    # Tools.go_borrow(self.driver, num=1)
    def go_borrow(self):
        self.driver.find_element_by_id(ut['until']['return_id']).click()

    # 选择更多 ---> 切换用户 ---> 输入已经存在的用户 ---> 验证已经存在用户的登录密码
    @file_data(test_data)
    def test_3(self, var):
        self.go_borrow()
        # 选择更多 ---> 切换用户 ---> 输入登录密码
        password = var[0]['info']['data']['pawd']
        time.sleep(0.5)
        Login.change(self.driver, option=0)
        time.sleep(0.5)
        self.driver.find_element_by_id(ut['jx_register']['phone_id']).click()  #
        for i in Tools.Tools.number('18538097372'):
            self.driver.find_element_by_id(ut['until'][i]).click()
        logger.info(f'账号输入完成，输入的账号信息是--->【{18538097372}】')
        time.sleep(1.0)
        self.driver.find_element_by_id(ut['jx_register']['next_id']).click()
        logger.info('单击下一步按钮，页面跳转......')
        time.sleep(0.5)
        self.driver.find_element_by_id(ut['jx_wallet']['password']).send_keys(password)
        logger.info(f'输入的用户登录密码是【{password}】')
        time.sleep(0.5)
        self.driver.find_element_by_id(ut['jx_wallet']['login_id']).click()
        logger.info('点击登录按钮......')
        time.sleep(2.0)
        # 截图当前登录状态
        self.driver.get_screenshot_as_file(Tools.Tools.cut('login') + '.png')
        time.sleep(1.0)
        Tools.swipe_up(self.driver, t=500, n=1)
        try:  # 尝试断言我要借款按钮文本
            b = self.driver.find_element_by_id(bp['borrow']['borrow_id']).text
            self.assertEqual('我要借款', b)
            # 若断言正确，则截图并执行 ---> 退出登录 sign_out函数，便于下一用例执行。
            self.add_img()
            self.driver.get_screenshot_as_file(Tools.Tools.cut('test_login') + '.png')
            Tools.is_element(self.driver, element=ut['until']['mine_id'])
            time.sleep(2.0)
            Sign_out.sign_out(self.driver, option=True)
            # 在设置中退出后页面并不会自动跳转至 ---> 借款首页，需要我的页面点击借款按钮
            self.driver.find_element_by_id(ut['until']['borrowd_id']).click()
        except:
            # 若try执行异常, except捕获,断言借享钱包页面--->登录文本
            t1 = Tools.is_toast(self.driver, toast_text='你输入的用户或密码不正确，请重新输入。')
            self.driver.find_element_by_id(ut['jx_wallet']['login_id']).click()
            t2 = Tools.is_toast(self.driver, toast_text='密码必须为6~16字')
            if t1:
                self.assertTrue(t1)   # 断言 t方法的返回值是否为真
            elif t2:
                self.assertTrue(t2)   # 断言 t方法的返回值是否为真

            # 登录失败之后需要回到借款首页继续测试其他情景 ---> 此处执行左返回 或这直接执行self.driver.keyboard(4)
            self.driver.find_element_by_id(ut['until']['return_id']).click()
            time.sleep(1.0)


# 以下操作先要进入登录状态，上面的操作最终退出了登录，所以要先登录
    def test_4(self):
        """修改账户的交易密码"""
        Login.login(Jx_1.driver, password='123456')
        time.sleep(0.5)
        Tools.is_element(self.driver, element=ut['until']['mine_id'])
        time.sleep(2.0)
        Set_up.update_pay_password(self.driver, '123456', '123456', '123456')
        # if self.driver.find_element_by_id('com.jxmoney.gringotts:id/iv_close'):
        #     self.driver.find_element_by_id('com.jxmoney.gringotts:id/iv_close').click()
        # else:
        #     pass
        try:
            # 修改成功则弹出完成提示窗口、旧密码输入错误、弹出提示窗口其他弹出toast弹窗
            # argument.find_element_by_id(ut['until']['suerw_id']).click()
            assert_element = self.driver.find_element_by_id(ut['until']['note_id']).text
            self.assertEqual('交易密码修改成功', assert_element, msg="输入正确的交易密码，相同的新交易密码")
            self.driver.find_element_by_id(ut['until']['suerw_id']).click()
        except:
            """
            交易密码修改失败时的断言
            情景1、原始交易密码输入错误
            情景2、设置密码与确认密码不一样
            情景3、设置密码或确认密码不足6位
            """
            # 原交交易密码错误
            try:
                elem = self.driver.find_element_by_id(ut['until']['note_id']).text
                self.assertEqual('原密码错误', elem)
            except:
                # 情景2、3
                t = Tools.is_toast(self.driver, '两次密码不一致,请重新输入')
                self.assertTrue(t)
            Tools.go_borrow(self.driver, num=2)

    def test_5(self):
        """测试意见反馈"""
        self.driver.keyevent(4)
        time.sleep(1.0)
        Tools.swipe_up(self.driver, n=1)
        t1 = MyPage.feedback(self.driver, '测试')
        self.assertEqual('意见反馈', t1, msg="断言意见反馈页面标题")
        t2 = Tools.is_toast(self.driver, '反馈成功')
        self.assertTrue(t2)
        Tools.go_borrow(self.driver, num=1)

    @file_data(password_data)
    def test_6(self, var):
        """修改账户的登录密码"""
        self.driver.find_element_by_id(ut['until']['mine_id']).click()

        datas = var[0]['info']['data']
        Set_up.update_login_password(
            self.driver,
            old_password=datas['old'],
            new_password1=datas['new1'],
            new_password2=datas['new2']
        )
        try:
            time.sleep(3.0)
            element = self.driver.find_element_by_id(ut['until']['note_id']).text
            self.driver.find_element_by_id(ut['until']['suerw_id']).click()
            self.assertEqual('修改登录密码成功', element, msg=var[0]['info']['description'])
            self.driver.keyevent(4)
        except:
            time.sleep(2.0)
            element = self.driver.find_element_by_id(my['change_password_for_login'][-1]).text
            self.assertEqual('完  成', element, msg=var[0]['info']['description'])
            t1 = Tools.is_toast(self.driver, '原密码错误')
            self.driver.find_element_by_id(my['change_password_for_login'][-1]).click()
            t2 = Tools.is_toast(self.driver, '密码长度要在6~16位哦')
            self.driver.find_element_by_id(my['change_password_for_login'][-1]).click()
            t3 = Tools.is_toast(self.driver, '两次密码不一致')
            self.driver.find_element_by_id(my['change_password_for_login'][-1]).click()
            t4 = Tools.is_toast(self.driver, '请输入旧密码')
            if t1:
                self.assertTrue(t1)
            elif t2:
                self.assertTrue(t2)
            elif t3:
                self.assertTrue(t3)
            elif t4:
                self.assertTrue(t4)

            Tools.go_borrow(self.driver, num=2)


if __name__ == '__main__':
    # pass
    Tools.Tools().html_report(Jx_1, title="测试报告", description="描述无")






