# -*- coding: utf-8 -*- 

# @Time : 2018/12/28 下午3:30 

# @Author : 废柴 

# @Project: Jx

# @FileName : Jx-02.py 

# @Software: PyCharm

# @Desc : ==============================================

# Life is Short I Use Python!!!                      ===

# If this runs wrong,don't ask me,I don't know why;  ===

# If this runs right,thank god,and I don't know why. ===

# Maybe the answer,my friend,is blowing in the wind. ===

# ======================================================
"""
测试借享App未登录状态所有功能
"""
import os
import time
import warnings
import unittest
from Until import Tools, logger
from appium import webdriver
from Config.Base import DesiredCaps

# ---------------------
#  日志配置
# ---------------------

logger = logger.get_logger('login')

# ---------------------
# 配置文件开始区域
# ---------------------

bp = Tools.Tools.element('BorrowPage.yaml')
ut = Tools.Tools.element('Until.yaml')

"""
2019-01-14 此脚本没有bug
2019-01-22 此脚本更该诸多内容，鬼知道有没有bug、有就优化呗。
"""
# ---------------------
# app启动配置文件
# ---------------------

ac = Tools.info()
DESIRED_CAPS = DesiredCaps.DesiredCaps(device_id=ac[0], version=ac[1], app_package=ac[2][0], app_activity=ac[2][1])


class Jx_02(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        warnings.simplefilter('ignore', ResourceWarning)
        cls.driver = webdriver.Remote('http://127.0.0.1:4723/wd/hub', DESIRED_CAPS.normal())
        cls.driver.wait_activity('.ui.main.MainActivity', 30)

    def test_1(self):
        """点击马上登录跳转至借享钱包登录页面"""
        self.driver.find_element_by_id(bp['login_id']).click()
        time.sleep(0.5)
        title = self.driver.find_element_by_id(ut['until']['title_id']).text
        self.assertEqual("借享钱包", title, msg="验证点击马上登录进入借享钱包登录页面")
        self.driver.keyevent(4)  # 相当于点击手机底部的返回键
        time.sleep(0.2)

    def test_2(self):
        """查看费率跳转至借享钱包登录页面"""
        self.driver.find_element_by_id(bp['fee_id']).click()
        time.sleep(0.5)
        title = self.driver.find_element_by_id(ut['until']['title_id']).text
        self.assertEqual("借享钱包", title, msg="验证点击马上登录进入借享钱包登录页面")
        self.driver.keyevent(4)

    def test_3(self):
        """点击还款按钮跳转至借享钱包登录页面"""
        self.driver.find_element_by_id(ut['until']['pay_id']).click()
        time.sleep(0.5)
        title = self.driver.find_element_by_id(ut['until']['title_id']).text
        self.assertEqual("借享钱包", title, msg="验证点击马上登录进入借享钱包登录页面")
        self.driver.keyevent(4)

    def test_4(self):
        """点击我的按钮跳转至借享钱包登录页面"""
        self.driver.find_element_by_id(ut['until']['mine_id']).click()
        time.sleep(0.5)
        title = self.driver.find_element_by_id(ut['until']['title_id']).text
        self.assertEqual("借享钱包", title, msg="验证点击马上登录进入借享钱包登录页面")
        self.driver.keyevent(4)

    def test_5(self):
        """点击到账金额跳转至借享钱包登录页面"""
        self.driver.find_element_by_id(bp['money_id']).click()
        time.sleep(0.5)
        title = self.driver.find_element_by_id(ut['until']['title_id']).text
        self.assertEqual("借享钱包", title, msg="验证点击马上登录进入借享钱包登录页面")
        self.driver.keyevent(4)

    @classmethod
    def tearDownClass(cls):
        cls.driver.quit()


if __name__ == '__main__':
    Tools.Tools().html_report(
        Jx_02,
        title="未登录状态UI测试报告",
        description="验证未登录状态跳转至借享钱包登录页面功能"
    )
