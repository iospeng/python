# -*- coding: utf-8 -*- 

# @Time : 2018/12/28 下午3:37 

# @Author : 废柴 

# @Project: Jx

# @FileName : Jx-03.py 

# @Software: PyCharm

# @Desc : ==============================================

# Life is Short I Use Python!!!                      ===

# If this runs wrong,don't ask me,I don't know why;  ===

# If this runs right,thank god,and I don't know why. ===

# Maybe the answer,my friend,is blowing in the wind. ===

# ======================================================

import time
import warnings
import unittest
from Until import Tools
from Until import logger
from Config.Base import DesiredCaps
from appium import webdriver
from Config import BorrowPage, Login, MyPage

# -----------------------
# 测试xx功能的测试用例集合
# ----------------------


# ---------------------
# 配置文件开始区域
# ---------------------

bp = Tools.Tools.element('BorrowPage.yaml')
ut = Tools.Tools.element('Until.yaml')
my = Tools.Tools.element('MyPage.yaml')

# ---------------------
#  日志配置
# ---------------------

logger = logger.get_logger('login')

# ---------------------
# app启动配置文件
# ---------------------

ac = Tools.info()
DESIRED_CAPS = DesiredCaps.DesiredCaps(device_id=ac[0], version=ac[1], app_package=ac[2][0], app_activity=ac[2][1])


class Jx_03(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        warnings.simplefilter('ignore', ResourceWarning)
        cls.driver = webdriver.Remote('http://127.0.0.1:4723/wd/hub', DESIRED_CAPS.normal())
        cls.driver.wait_activity('.ui.main.MainActivity', 30)

    def make_sure(self, password):
        # 检测当前状态时候为登录状态
        item = self.driver.find_element_by_id(bp['borrow']['borrow_id']).text
        if item == '马上登录':
            # 开始调用登录函数
            Login.login(self.driver, password)
            item = self.driver.find_element_by_id(bp['borrow']['borrow_id']).text
            if item == '我要借款':
                pass
            else:
                # 截图保存至异常处理、重新进行登录操作
                pass
        elif item == '我要借款':
            # 进入登录状态，执行流程测试
            return "已经登录"

    def test_1(self):
        """验证费率"""
        time.sleep(2.0)
        self.make_sure(password='123456')
        fee_data = []
        capital = 1000  # 后期将此处写成一个参数，根据穿参数更改借款金额
        interest = capital * (0.5 / 100)  # 借款利息
        use_1 = capital * (4 / 100)  # 快速信审费
        use_2 = capital * (4 / 100)  # 平台使用费
        use_3 = capital * (7 / 100)  # 代收通道费
        use_4 = capital * (4 / 100)  # 账户管理费
        total = interest + use_4 + use_3 + use_2 + use_1
        fee_data.append(str(float(interest)) + '元')
        fee_data.append(str(float(use_1)) + '元')
        fee_data.append(str(float(use_2)) + '元')
        fee_data.append(str(float(use_3)) + '元')
        fee_data.append(str(float(use_4)) + '元')
        fee_data.append(str(float(total)) + '元')
        # 点击查看费率详情
        self.driver.find_element_by_id(bp['fee_id']).click()
        time.sleep(0.5)
        fee = self.driver.find_elements_by_id('com.jxmoney.gringotts:id/tv_cost_')
        fee_info = []
        count = 0
        for i in fee:
            fee_info.append(i.text)
        # 断言费用详情
        for i in fee_data:
            if i in fee_info:
                self.assertEqual(i, fee_info[count])
            count += 100
        # 点击我知道了，测试完成
        self.driver.find_element_by_id(bp['know_id']).click()

    # -------------------------------------
    # 测试我的页面相关功能；1、消息中心；2、帮助中心
    # -------------------------------------

    def test_2(self):
        """测试帮助中心"""
        self.driver.find_element_by_id(ut['until']['mine_id']).click()
        time.sleep(3.0)
        Tools.swipe_up(self.driver, n=1)
        MyPage.help_center(self.driver)
        self.driver.keyevent(4)

    def test_3(self):
        """测试消息中心"""
        time.sleep(1.0)
        self.driver.find_element_by_id(ut['until']['mine_id']).click()
        logger.info('点击我的按钮，等在页面元素加载')
        MyPage.msg_center(self.driver)
        # 回退至我的页面 n 为回退的次数，类的实例对象调用Tools类的方法
        Tools.Tools.go_back(self.driver)

    def test_4(self):
        """测试借款记录"""
        # 每个time.sleep都是一把辛酸泪
        time.sleep(1.0)
        self.driver.find_element_by_id(ut['until']['mine_id']).click()
        time.sleep(2.0)
        self.driver.find_element_by_id(my['mypage'][-1]).click()
        MyPage.record(self.driver)
        element = self.driver.find_element_by_id(ut['until']['title_id']).text
        self.assertEqual('借款详情', element)
        logger.info('正在回退至我的页面')
        Tools.Tools.go_back(self.driver, n=2)

    def test_5(self):
        """测试推荐好友功能"""
        time.sleep(1.0)
        self.driver.find_element_by_id(ut['until']['mine_id']).click()
        for i in range(4):
            MyPage.recommend_friend(self.driver, option=i)
            Tools.Tools.cut('test_5')

    @classmethod
    def tearDownClass(cls):
        cls.driver.quit()


if __name__ == '__main__':

    Tools.Tools().html_report(Jx_03, title="测试报告", description="描述无")
