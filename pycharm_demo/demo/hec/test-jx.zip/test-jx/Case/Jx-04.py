# -*- coding: utf-8 -*- 

# @Time : 2019/1/12 下午3:06 

# @Author : 废柴 

# @Project: Jx

# @FileName : Jx-04.py 

# @Software: PyCharm

# @Desc : ==============================================

# Life is Short I Use Python!!!                      ===

# If this runs wrong,don't ask me,I don't know why;  ===

# If this runs right,thank god,and I don't know why. ===

# Maybe the answer,my friend,is blowing in the wind. ===

# ======================================================

import time
from Until import logger
import warnings
import unittest
from Until import Tools
from appium import webdriver
from Config import BorrowPage, Login, MyPage
from Config.Base import DesiredCaps
# -----------------------
# 测试xx功能的测试用例集合
# ----------------------


# ---------------------
# 配置文件开始区域
# ---------------------

bp = Tools.Tools.element('BorrowPage.yaml')
ut = Tools.Tools.element('Until.yaml')
my = Tools.Tools.element('MyPage.yaml')

# ---------------------
#  日志配置
# ---------------------

logger = logger.get_logger('login')

# ---------------------
# app启动配置文件
# ---------------------

ac = Tools.info()
DESIRED_CAPS = DesiredCaps.DesiredCaps(device_id=ac[0], version=ac[1], app_package=ac[2][0], app_activity=ac[2][1])


class Jx_04(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        warnings.simplefilter('ignore', ResourceWarning)
        cls.driver = webdriver.Remote('http://127.0.0.1:4723/wd/hub', Tools.Tools.config())
        cls.driver.wait_activity('.ui.main.MainActivity', 30)

    # def test_1(self):
    #     """已经绑定银行卡，并设置交易密码之后，已登录状态下申请借款"""
    #     Tools.swipe_up(self.driver, n=1)
    #     t = BorrowPage.borrow(self.driver, pay_password='123456')
    #     self.assertEqual('借款', t[0])
    #     self.assertEqual('申请成功', t[1])
    """
    test_2 执行时如果存在三张卡时，绑卡失败，存在一张卡时，不是在验证绑定借款绑定第一行卡

    """

    def test_2(self):
        """测试未借款时绑卡"""

        Tools.swipe_up(self.driver, n=1)
        self.driver.find_element_by_id(bp['borrow']['borrow_id']).click()
        time.sleep(2.0)
        """
        补充知识：
        1、按钮置灰，此时不可点击状态；如何判断按钮是否能被点击？使用is_enabled()
        2、判断这个页面元素是不是显示出来，返回boolean；使用is_displayed()
        3、复选框或者是单选框，判断这个框是不是被勾选了；使用is_selected()
        """
        if self.driver.find_element_by_id(bp['borrowpage']['verify_id']).is_enabled():
            t = BorrowPage.borrow(self.driver, pay_password='123456')
            self.assertEqual('借款', t[0])
            self.assertEqual('申请成功', t[1])
        else:
            BorrowPage.bind_bank_borrow(self.driver, bank_number='6212345612345678258', sms_code='123456', phone='18538097372')

    @classmethod
    def tearDownClass(cls):
        cls.driver.quit()


if __name__ == '__main__':

    Tools.Tools().html_report(Jx_04, title="测试报告", description="描述无")
