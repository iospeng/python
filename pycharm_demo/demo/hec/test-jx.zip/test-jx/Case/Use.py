# -*- coding: utf-8 -*- 

# @Time : 2018/12/28 下午3:37 

# @Author : 废柴 

# @Project: Jx

# @FileName : Use.py 

# @Software: PyCharm

# @Desc : ==============================================

# Life is Short I Use Python!!!                      ===

# If this runs wrong,don't ask me,I don't know why;  ===

# If this runs right,thank god,and I don't know why. ===

# Maybe the answer,my friend,is blowing in the wind. ===

# ======================================================
'''
调试脚本
'''

import warnings
import time
# from TestConfig.settings import *
from Until import Tools
from appium import webdriver
from Config.Base import DesiredCaps

ac = Tools.info()


DESIRED_CAPS = DesiredCaps.DesiredCaps(device_id=ac[0], version=ac[1], app_package=ac[2][0], app_activity=ac[2][1])
print(DESIRED_CAPS.all_config())

class Test(object):

    def __init__(self):
        warnings.simplefilter('ignore', ResourceWarning)
        self.driver = webdriver.Remote('http://127.0.0.1:4723/wd/hub', DESIRED_CAPS.all_config())
        self.driver.wait_activity('.ui.main.MainActivity', 30)

    def close(self):
        self.driver.quit()


if __name__ == '__main__':
    go = Test()
    time.sleep(10.0)
    go.close()



# from selenium.webdriver.support.ui import WebDriverWait
# from selenium.webdriver.support import expected_conditions as EC
# from Until import Tools
# from Config import BorrowPage
# from Config import Pay
# from Config import MyPage
# from Config import Set_up,Login




# bp = Tools.Tools.element('BorrowPage.yaml')
# ut = Tools.Tools.element('Until.yaml')
# my = Tools.Tools.element('MyPage.yaml')
# # elements = Tools.element()
#
#
# class Use(object):
#
#     def __init__(self):
#         warnings.simplefilter('ignore', ResourceWarning)
#         self.driver = webdriver.Remote('http://127.0.0.1:4723/wd/hub', Tools.Tools.DESIRED_CAPS)
#         self.driver.wait_activity('.ui.main.MainActivity', 30)
#         self.bp = BorrowPage.bp
#
#     def use(self):
#         time.sleep(2.0)
#         self.driver.find_element_by_id('com.jxmoney.gringotts:id/ll_total_and_profit').click()
#         time.sleep(1.0)
#         fee = self.driver.find_elements_by_id('com.jxmoney.gringotts:id/tv_cost_')
#         for i in fee:
#             print(i.text)
#
#     def make_sure(self, password):
#         # 检测当前状态时候为登录状态
#         item = self.driver.find_element_by_id(bp['borrow']['borrow_id']).text
#         if item == '马上登录':
#             # 开始调用登录函数
#             Login.login(self.driver, password)
#             item = self.driver.find_element_by_id(bp['borrow']['borrow_id']).text
#             if item == '我要借款':
#                 pass
#             else:
#                 # 截图保存至异常处理、重新进行登录操作
#                 pass
#         elif item == '我要借款':
#             # 进入登录状态，执行流程测试
#             return "已经登录"
#
#     def test3(self):
#         """测试消息中心"""
#         # self.make_sure(password='123456')
#         time.sleep(1.0)
#         self.driver.find_element_by_id(ut['until']['mine_id']).click()
#         time.sleep(2.0)
#         self.driver.find_element_by_id(my['mypage'][2]).click()
#         time.sleep(2.0)  # 我也很无奈啊，它是h5页面加载慢！！！我有什么办法？
#         # title = self.driver.find_element_by_id()
#         msg = self.driver.find_element_by_id(my['msg'][1]).find_elements_by_class_name(my['msg'][2])
#         num = len(msg) / 2
#         i = 1
#         n = 1
#         while n <= num:
#             msg[i].click()
#             time.sleep(2.0)
#             self.driver.keyevent(4)
#             i += 2
#             n += 1
#
#         self.driver.keyevent(4)
#
#     def use_1(self):
#         time.sleep(1.0)
#         self.driver.find_element_by_id(ut['until']['mine_id']).click()
#         MyPage.recommend_friend(self.driver, option=3)
#         # self.driver.find_element_by_id('com.tencent.mm:id/cib').send_keys('hello world!')
#         # self.driver.find_element_by_id('com.tencent.mm:id/cib').click()
#         self.driver.find_element_by_id('com.tencent.mm:id/cib').send_keys(u'那一年江南月下 你弹琵琶急催我上马，任心事喧哗 你要留下 却不叫我牵挂'
#                                                                           u'你说缘如指间沙 握不住就放下，管它风扫落花 赌上一生陪着你挣扎，指间的沙 淹没年华 如今你在哪')
#         self.driver.find_element_by_id('com.tencent.mm:id/j0').click()

    # def use(self):
    #     swipe_up(self.driver, n=2)
    #     time.sleep(1.0)
    #     self.driver.find_element_by_id(self.element['borrow_id']).click()
    #     BorrowPage.change_bank_borrow(self.driver, bank_number='621212345678907896', phone='18538097372', sms_code='123456')
    #     self.driver.keyevent(111)
    #
    # def use_1(self):
    #     swipe_up(self.driver, n=2)
    #     time.sleep(1.0)
    #     self.driver.find_element_by_id(self.element['borrow_id']).click()
    #     time.sleep(1.0)
    #     self.driver.find_element_by_id(self.element['change_id']).click()
    #     time.sleep(10.0)
    #     BorrowPage.change_default_card(self.driver)
    #     self.driver.quit()
    #
    # def use_2(self):
    #     swipe_up(self.driver, n=2)
    #     time.sleep(1.0)
    #     BorrowPage.borrow(self.driver, '123456')
    #
    # def use_3(self):
    #     swipe_up(self.driver, n=2)
    #     time.sleep(1.0)
    #     Pay.pay(self.driver)
    #
    # def use_4(self):
    #     swipe_up(self.driver, n=2)
    #     time.sleep(1.0)
    #     Pay.renewal(self.driver)
    #
    # def use_5(self):
    #     self.driver.find_element_by_id(self.element['pay_id']).click()
    #     time.sleep(0.5)
    #     Pay.card_pay(self.driver)
    #
    # def use_6(self):
    #     swipe_up(self.driver, n=2)
    #     time.sleep(1.0)
    #     self.driver.find_element_by_id(self.bp['borrow']['borrow_id']).click()
    #     time.sleep(2.0)
    #     BorrowPage.change_bank_borrow(self.driver, bank_number='6212123412341234567', sms_code='123456', phone='18538097372')
    #
    # def use_7(self):
    #     swipe_up(self.driver, n=2)
    #     time.sleep(1.0)
    #     self.driver.find_element_by_id(self.bp['borrow']['borrow_id']).click()
    #     time.sleep(5.0)
    #     BorrowPage.change_default_card(self.driver)
    #
    # def use_8(self):
    #     MyPage.recommend_friend(self.driver, option=0)
    #
    # def use_9(self):
    #
    #     Pay.more_pay_way(self.driver)
    # def use_10(self):
    #     time.sleep(1.0)
    #     self.driver.find_element_by_id(ut['until']['mine_id']).click()
    #     time.sleep(2.0)
    #     self.driver.find_element_by_id(my['mypage'][-1]).click()
    #     time.sleep(1.0)
    #     record = self.driver.find_elements_by_id(bp['record'][0])
    #     print(record)
    #     record[0].click()
    #     # MyPage.record(self.driver)
    #
    #     Tools.Tools.go_back(self.driver, n=2)

    # def use_11(self):
    #
    #     # self.driver.keyevent(4)
    #     time.sleep(1.0)
    #     self.driver.find_element_by_id('com.jxmoney.gringotts:id/tv_rent_btn').click()
    #     time.sleep(3.0)
    #     self.driver.find_element_by_id('com.jxmoney.gringotts:id/et_password').send_keys('12312345')
    #     time.sleep(1.0)
    #     self.driver.find_element_by_id('com.jxmoney.gringotts:id/tv_login').click()
    #     # toast_loc = ("xpath", ".//*[contains(@text,'密码必须为6~16字符')]")
    #     # t = WebDriverWait(self.driver, 10, 0.1).until(EC.presence_of_element_located(toast_loc))
    #     if Tools.is_toast(self.driver, toast_text='你输入的用户或密码不正确，请重新输入。'):
    #         print('toast 存在')
    #     else:
    #         print('toast 不存在')
    #     # time.sleep(0.5)
    #     # t = self.driver.find_element_by_class_name('android.widget.Toast').text
    #     # print(t.text)
    #
    #     # Set_up.about_us(self.driver)
    # def close(self):
    #     self.driver.quit()

#
# if __name__ == '__main__':
#     instance = Use()
#     # instance.test3()
#     # instance.make_sure(password='123456')
#     instance.test3()
#     instance.close()


