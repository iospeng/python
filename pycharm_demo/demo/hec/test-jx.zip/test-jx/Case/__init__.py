# -*- coding: utf-8 -*- 

# @Time : 2018/12/28 下午3:26 

# @Author : 废柴 

# @Project: Jx

# @FileName : __init__.py.py 

# @Software: PyCharm

# @Desc : ==============================================

# Life is Short I Use Python!!!                      ===

# If this runs wrong,don't ask me,I don't know why;  ===

# If this runs right,thank god,and I don't know why. ===

# Maybe the answer,my friend,is blowing in the wind. ===

# ======================================================

