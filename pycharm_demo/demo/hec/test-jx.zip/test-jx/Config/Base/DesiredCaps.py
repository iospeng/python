# -*- coding: utf-8 -*- 

# @Time : 2019/1/15 下午8:25 

# @Author : 废柴 

# @Project: TestConfig

# @FileName : DesiredCaps.py 

# @Software: PyCharm

# @Desc : ==============================================

# Life is Short I Use Python!!!                      ===

# If this runs wrong,don't ask me,I don't know why;  ===

# If this runs right,thank god,and I don't know why. ===

# Maybe the answer,my friend,is blowing in the wind. ===

# ======================================================

from TestConfig.settings import *

"""
启动app的配置脚本文件
"""


class DesiredCaps(object):

    def __init__(self, device_id, app_package, app_activity, version):
        """
        初始化app配置文件
        :param version: 手机系统版本号
        :param device_id: 手机序列号
        :param app_package: app包名
        :param app_activity: 活动activity
        """
        self.deviceId = device_id
        self.appPackage = app_package
        self.appActivity = app_activity
        self.version = version
        self.DESIRED_CAPS = {
            "device": "android",
            "platformName": "Android",
            "platformVersion": f"{self.version}",  # 6.0.1
            "deviceName": f"{self.deviceId}",
            "appPackage": f"{self.appPackage}",
            "appActivity": f"{self.appActivity}",
            'automationName': 'Uiautomator2',  # 启动安卓调试文件
            "unicodeKeyboard": "True",  # 启用Appium键盘
            "resetKeyboard": "True",  # 隐藏手机系统键盘
            "noReset": "True"  # 每次启动app保存数据，不再重新加载启动
        }
        """
        不同的测试场景需要使用到不同的初始化配置文件，具体原因写过代码的人才知道为什么？很扎心的痛！！！
        """

    def reset(self):
        """
        启动安卓调试文件，每次启动app重新加载，不保留数据
        :return: self.DESIRED_CAPS
        """
        self.DESIRED_CAPS.pop('noReset')
        return self.DESIRED_CAPS

    def no_auto(self):
        """
        不启动安卓调试文件，每次启动app加载用户数据
        :return: self.DESIRED_CAPS
        """
        self.DESIRED_CAPS.pop('automationName')
        return self.DESIRED_CAPS

    def normal(self):
        """
        正常配置的启动配置文件
        :return: self.DESIRED_CAPS
        """
        self.DESIRED_CAPS.pop('automationName')
        self.DESIRED_CAPS.pop('unicodeKeyboard')
        self.DESIRED_CAPS.pop('resetKeyboard')
        return self.DESIRED_CAPS

    def use_unicode_keyboard(self):
        """
        启用appium键盘，隐藏手机系统键盘，不启用Uiautomator2
        :return: self.DESIRED_CAPS
        """
        self.DESIRED_CAPS.pop('automationName')
        return self.DESIRED_CAPS

    def all_config(self):
        """
        启用全部配置
        :return: self.DESIRED_CAPS
        """
        return self.DESIRED_CAPS
