# -*- coding: utf-8 -*- 

# @Time : 2019/1/15 下午8:23 

# @Author : 废柴 

# @Project: TestConfig

# @FileName : __init__.py.py 

# @Software: PyCharm

# @Desc : ==============================================

# Life is Short I Use Python!!!                      ===

# If this runs wrong,don't ask me,I don't know why;  ===

# If this runs right,thank god,and I don't know why. ===

# Maybe the answer,my friend,is blowing in the wind. ===

# ======================================================

