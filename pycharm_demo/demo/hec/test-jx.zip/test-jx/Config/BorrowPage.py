# -*- coding: utf-8 -*- 

# @Time : 2018/12/28 下午3:31 

# @Author : 废柴 

# @Project: Jx

# @FileName : BorrowPage.py 

# @Software: PyCharm

# @Desc : ==============================================

# Life is Short I Use Python!!!                      ===

# If this runs wrong,don't ask me,I don't know why;  ===

# If this runs right,thank god,and I don't know why. ===

# Maybe the answer,my friend,is blowing in the wind. ===

# ======================================================

import time
from Until import logger
from Until import Tools


# ---------------------
#  日志配置
# ---------------------

logger = logger.get_logger('borrow')

# ---------------------
#  页面元素加载
# ---------------------
ac = Tools.info()
pp = Tools.Tools.element('{}/PayPage.yaml'.format(ac[-1]))
bp = Tools.Tools.element('{}/BorrowPage.yaml'.format(ac[-1]))
ut = Tools.Tools.element('{}/Until.yaml'.format(ac[-1]))
my = Tools.Tools.element('{}/MyPage.yaml'.format(ac[-1]))


def until(argument, nums, password, code, sms, option=False):
    """A new app registration, login function common module"""
    logger.info('开始测试新用户注册功能')
    # 对借享钱包页面进行截图
    title_1 = argument.find_bp_by_id(ut['until']['title_id']).text
    time.sleep(0.5)
    argument.get_screenshot_as_file(Tools.Tools.cut('until') + '.png')
    argument.find_element_by_id(ut['jx_register']['phone_id']).click()
    time.sleep(0.5)
    logger.info('# 唤醒自定义键盘')
    for num in Tools.Tools.number(num=nums):
        argument.find_bp_by_id(ut['until'][num]).click()
    logger.info(f'输入的手机号是【{num}】')
    argument.find_element_by_id(ut['until']['back_id']).click()
    logger.info('关闭自定义键盘')
    time.sleep(0.5)
    # 借享钱包页面 ----> 注册页面
    title_2 = argument.find_bp_by_id(ut['until']['title_id']).text
    argument.get_screenshot_as_file(Tools.Tools.cut('until') + '.png')
    argument.find_element_by_id(ut['until']['nx_id']).click()
    logger.info('点击下一步按钮，等待注册页面加载')
    time.sleep(1.0)
    argument.find_element_by_id(ut['until']['p_id']).send_keys(code)
    logger.info(f'写入的图片验证码是--->【{code}】')
    if option:
        argument.find_element_by_id(ut['until']['gp_id']).click()
        logger.info('正在获取新的图片验证码......')
        time.sleep(0.5)
        argument.find_element_by_id(ut['until']['p_id']).send_keys(code)
        logger.info(f'写入的图片验证码是--->【{code}】')
    else:
        argument.find_element_by_id(ut['until']['gs_id']).click()
        logger.info('正在获取手机短信验证码......')
        argument.find_element_by_id(ut['until']['s_id']).send_keys(sms)
        logger.info('已经获取到短信验证码，正在输入短信验证码......')
        argument.find_element_by_id(ut['jx_register']['set_password_id']).send_keys(password)
        logger.info(f'输入的短信验证码是--->【{password}】')
        argument.keyevent(111)
        logger.info('关闭系统键盘')
        argument.find_element_by_id(ut['until']['nx_id']).click()
        logger.info('新用户注册功能测试结束')
        time.sleep(2.0)
        # 对注册成功之后的页面进行截图 注册页面 ----> 借款首页
        argument.get_screenshot_as_file(Tools.Tools.cut('login_success') + '.png')
    return title_1, title_2


# 借款首页 ---> 借款页面 ---> 温馨提示弹窗
def borrow(argument, pay_password):
    """申请借款；流程：我要借款--确认借款--输入交易密码;借款操作完成"""
    logger.info('开始测试借款功能......')
    argument.find_element_by_id(bp['borrow']['borrow_id']).click()
    logger.info('点击我要借款按钮，等待借款页面元素加载.....')
    time.sleep(2.0)
    t1 = argument.find_element_by_id(ut['until']['title_id']).text
    argument.find_element_by_id(bp['borrowpage']['verify_id']).click()
    logger.info('点击确认申请按钮......')
    # 此时app自动调用模拟键盘、输入交易密码
    for i in Tools.Tools.number(pay_password):
        argument.find_element_by_id(ut['until'][i]).click()
    logger.info(f'交易密码输入框填入的交易密码是【{pay_password}】')
    # 处理借款成功之后的温馨提示弹窗；直接点击确认---借款流程完成！
    time.sleep(2.0)  # 因测试环境请求接口响应数据缓慢，故此处的等待时间可能会更长，按需要对其进行更改
    argument.get_screenshot_as_file(Tools.Tools.cut('borrow') + '.png')
    t2 = argument.find_element_by_id('com.jxmoney.gringotts:id/tv_content').text
    argument.find_element_by_id(ut['until']['suerw_id']).click()
    logger.info('点击完成按钮。借款功能测试结束')
    return t1, t2  # 将返回的title作为断言的一部分


# 借款首页 ---> 查看服务费率
def fee(argument):
    """测试费率展示功能"""
    try:
        logger.info('开始测试服务费率 ......')
        argument.find_element_by_id(bp['fee_id']).click()
        time.sleep(0.5)
        argument.get_screenshot_as_file(Tools.Tools.cut('fee') + '.png')
        argument.find_element_by_id(bp['know_id']).click()
        logger.info('点击费率提示弹窗中的我知道了')
    except:
        logger.info('若未捕获元素，则自动截图')
        argument.driverget_screenshot_as_file(Tools.Tools.cut('fee-fail') + '.png')


# 借款首页 ---> 客服【电话客服】
def custom_service_call(argument, option=False):
    """测试电话客服功能"""
    logger.info('开始测试电话客服功能......')
    argument.find_element_by_id(bp['service']['f_id']).click()
    logger.info('点击客服图标，客服图标加载')
    time.sleep(1.0)
    # 截图
    argument.get_screenshot_as_file(Tools.Tools.cut('custom_service_call') + '.png')
    # 将近进行呼叫选择
    argument.find_element_by_id(bp['service']['type_service'][0]).click()
    logger.info('点击电话客服图标')
    if option:
        argument.find_element_by_id(bp['service']['call_id']).click()
    else:
        argument.find_element_by_id(bp['service']['call_id']).clcik()
    logger.info('测试电话客服功能结束！')


# 借款首页 ---> 客服【在线客服】
def custom_service_online(argument, text):
    """测试在线客服功能"""
    logger.info('开始测试在线客服功能 ......')
    argument.find_element_by_id(bp['service']['f_id']).click()
    logger.info('点击客服图标，客服图标加载')
    time.sleep(1.0)
    # 截图
    argument.get_screenshot_as_file(Tools.Tools.cut('custom_service_call') + '.png')
    # 启动在线客服功能
    argument.find_element_by_id(bp['service']['type_service'][1]).click()
    logger.info('点击在线客服图标')
    argument.get_screenshot_as_file(Tools.Tools.cut('custom_service_online') + '.png')
    time.sleep(1.0)
    try:
        if argument.find_element_by_id(my['online'][0]):
            argument.find_element_by_id(my['online'][0]).send_keys(text)
            logger.info(f'发送的信息文本是【{text}】')
            argument.find_element_by_id(my['online'][1]).click()
            time.sleep(1.0)
            argument.get_screenshot_as_file(Tools.Tools.cut('custom_service_online') + '.png')
            logger.info('测试在线客服功能结束')
        else:
            pass
    except:
        # 启用留言板功能
        pass


# 借款页面 ---> 协议
def verify_borrow_agreement(argument):
    """测试借款协议及勾选框"""
    logger.info('开始测试借款协议......')
    argument.find_element_by_id(bp['borrowpage']['agreement_id']).click()
    logger.info('点击个人借款协议')
    time.sleep(5.0)
    title = argument.find_element_by_id(ut['until']['title_id']).text
    argument.get_screenshot_as_file(Tools.Tools.cut('verify_borrow_agreement') + '.png')
    argument.find_element_by_id(ut['until']['return_id']).click()
    argument.get_screenshot_as_file(Tools.Tools.cut('verify_borrow_agreement') + '.png')
    # 返回 ---> 借款页面
    argument.find_element_by_id(bp['borrowpage']['selectbox1_id']).click()
    argument.find_element_by_id(bp['borrowpage']['selectbox1_id']).click()
    logger.info('测试借款协议结束！')
    return title


# 借款页面 ---> 银行卡列表 ---> 绑定银行卡
def bind_bank_borrow(argument, bank_number, sms_code, phone):
    """申请借款过程中添加新卡----并借款"""
    argument.find_element_by_id(bp['borrowpage']['change_id']).click()
    logger.info('点击更换银行卡按钮，等待银行卡列表页面加载......')
    time.sleep(10.0)
    card_list = argument.find_element_by_id(bp['card_list']['card_list_id']).find_elements_by_class_name(
        bp['card_list']['cards_class'])
    logger.info('正在统计用户银行卡数量......')
    if 0 <= (len(card_list) / 2) < 3:
        argument.find_element_by_id(bp['card_list']['add_id']).click()
        logger.info('当前用户已经绑定的银行卡数量小于3张，点击添加银行卡按钮，等待绑定银行卡页面加载......')
        time.sleep(5.0)
    else:
        logger.info('当前绑定的用户银行卡数量大于3张......')
        return "已经绑定了三张银行卡"
    argument.get_screenshot_as_file(Tools.Tools.cut('change_bank_borrow') + '.png')
    # 选择 绑定新的银行卡
    argument.find_element_by_id(bp['card_bind']['bank_id']).click()
    logger.info('点击选择银行按钮，加载银行卡选择列表......')
    time.sleep(1.0)
    argument.find_element_by_xpath('//android.view.View[@content-desc="中国工商银行"]').click()
    logger.info('点击工商银行')
    time.sleep(0.5)
    argument.find_element_by_id(bp['card_bind']['card_number_id']).send_keys(bank_number)
    logger.info(f'银行卡输入框填入的数据是【{bank_number}】')
    argument.find_element_by_id(bp['card_bind']['phone_number_id']).send_keys(phone)
    logger.info(f'手机号输入框填入的数据是【{phone}】')
    argument.find_element_by_id(bp['card_bind']['get_sms_id']).click()
    logger.info('点击获取手机短信验证码按钮')
    time.sleep(0.5)
    argument.find_element_by_id(bp['card_bind']['code_id']).send_keys(sms_code)
    logger.info(f'验证码输入框填入的数据是【{sms_code}】')
    argument.keyevent(111)
    argument.find_element_by_id(bp['card_bind']['submit_id']).click()
    logger.info('点击确认绑定按钮')
    time.sleep(0.5)
    argument.get_screenshot_as_file(Tools.Tools.cut('change_bank_borrow') + '.png')


# 银行卡列表页面 ---> 更换默认银行卡
def change_default_card(argument, option=True):
    """银行卡列表----> 更换默认银行卡功能"""
    # 处理没有银行卡绑定时的操作
    argument.find_element_by_id(bp['borrowpage']['change_id']).click()
    logger.info('点击更换银行卡按钮，等待银行卡列表页面加载......')
    time.sleep(10.0)
    argument.get_screenshot_as_file(Tools.Tools.cut('change_default_card') + '.png')
    card_list = argument.find_element_by_id(bp['card_list']['card_list_id']).find_elements_by_class_name(bp['card_list']['cards_class'])
    logger.info('正在统计用户银行卡数量......')
    if 2 <= (len(card_list) / 2) < 3:
        """card_list中的索引值为1， 3， 5的元素是每张银行卡的可点击元素"""
        card_list[3].click()
        logger.info('将第二张银行卡切换为默认卡......')
        if option:
            argument.find_element_by_id(bp['card_list']['yes_id']).click()
            logger.info('点击确认切换，正在跳转至借款页面.....')
            # 切换成功之后跳转借款页面
            time.sleep(10.0)
            aver = argument.find_element_by_id(bp['borrowpage']['verify_id']).text
            print(aver)
            return aver
        else:
            argument.find_element_by_id(bp['card_list']['no_id']).click()
            logger.info('点击取消切换默认卡......')
            return "默认卡未更改"
    elif (len(card_list) / 2) == 1:
        logger.info('当前用户银行卡的数量为1张无法切换默认卡......')
        return "默认卡数量小于2张无法切换默认卡"
    else:
        return "用户未绑卡"


# 当用户未绑卡首次借款是走借款并绑卡流程: 我要借款 ---> 借款页面并绑卡 ---> 银行卡列表 --->
# 添加银行卡 ---> 添加成功后设置交易密码 ---> 回到借款页面

def first_borrow(argument):
    # 点击我要借款按钮
    argument.find_element_by_id(bp['borrow']['borrow_id']).click()
    # 需要给出验证时间
    argument.find_element_by_id(bp['borrowpage']['change_id']).click()
    # 进入添加银行卡列表页面 ---> 添加银行卡
    argument.find_element_by_id(bp['borrowpage']['change_bank_card']).click()
    # 需要等待时间 进入绑定银行卡页面
    pass
