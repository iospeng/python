# -*- coding: utf-8 -*- 

# @Time : 2018/12/28 下午3:32 

# @Author : 废柴 

# @Project: Jx

# @FileName : Login.py 

# @Software: PyCharm

# @Desc : ==============================================

# Life is Short I Use Python!!!                      ===

# If this runs wrong,don't ask me,I don't know why;  ===

# If this runs right,thank god,and I don't know why. ===

# Maybe the answer,my friend,is blowing in the wind. ===

# ======================================================

# -*-coding:utf-8 -*-
# /usr/bin/env python3
"""
description: function & config is this script
author: 废柴
time: 2018-12-09
tell you: Chinese is too low to write notes
"""
import time
from Until import logger
from TestConfig.settings import *
from Until.Tools import Tools, swipe_up, info

# ---------------------
#  日志配置
# ---------------------

logger = logger.get_logger('login')

# ---------------------
#  页面元素加载
# ---------------------
ac = info()
elements = Tools.element('{}/BorrowPage.yaml'.format(ac[-1]))
ut = Tools.element('{}/Until.yaml'.format(ac[-1]))


# 借款首页 ---> 借享钱包页面 ---> 借款首页 或 借款钱包页面 ---> 我的页面 【原因：退出之后，再次登录】
def login(argument, password):
    """点击马上登录进入登录页面，进行填写密码登录操作"""
    logger.info('开始测试已注册用户的登录密码......')
    if argument.find_element_by_id(elements['login_id']).is_displayed():
        argument.find_element_by_id(elements['login_id']).click()
    else:
        time.sleep(1.5)
        argument.find_element_by_id(elements['login_id']).click()
    logger.info('点击马上登录按钮，等待借享钱包页面加载......')
    time.sleep(1.0)
    argument.find_element_by_id(ut['jx_wallet']['password']).send_keys(password)
    logger.info(f'输入的用户登录密码是【{password}】')
    argument.find_element_by_id(ut['jx_wallet']['login_id']).click()
    logger.info('点击登录按钮......')
    time.sleep(2.0)
    # 截图当前登录状态
    argument.get_screenshot_as_file(Tools.cut('login') + '.png')


# 借款页面【未登录状态】---> 借款钱包 ---> 点击更多 ---> 切换账户
def change(argument, option):
    argument.find_element_by_id(elements['login_id']).click()
    logger.info('点击马上登录按钮')
    time.sleep(1.0)
    argument.find_element_by_id(ut['jx_wallet']['more_id']).click()
    logger.info('点击更多选项')
    argument.get_screenshot_as_file(Tools.cut('change') + '.png')
    if option == 0:
        argument.find_elements_by_class_name(ut['jx_wallet']['change_class'])[1].click()  # 切换账户
        logger.info('选择切换用户功能......')
        time.sleep(0.2)
        argument.get_screenshot_as_file(Tools.cut('change') + '.png')

    elif option == 1:
        argument.find_elements_by_class_name(ut['jx_wallet']['change_class'])[0].click()  # 注册
        logger.info('选择注册功能......')
        time.sleep(0.2)
        argument.get_screenshot_as_file(Tools.cut('change') + '.png')

    elif option == 2:
        argument.find_element_by_id(ut['jx_wallet']['cancel_id']).click()  # 取消
        logger.info('选择取消功能......')
        time.sleep(0.2)
        argument.get_screenshot_as_file(Tools.cut('change') + '.png')


def fill_in_account(argument, account, password):
    """在选择切换账户或者注册之后、输入账号操作,当账户存在时，验证其登录功能"""
    logger.info('聚焦账号输入框、启用App端自定义键盘、账号输入中......')
    argument.find_element_by_id(ut['jx_register']['phone_id']).click()  #
    for i in Tools.number(account):
        argument.find_element_by_id(ut[i]).click()
    logger.info(f'账号输入完成，输入的账号信息是--->【{account}】')
    time.sleep(1.0)
    argument.find_element_by_id(ut['jx_register']['next_id']).click()
    logger.info('单击下一步按钮，页面跳转......')
    try:
        time.sleep(1.0)
        item = argument.find_element_by_id(ut['jx_wallet']['login_id']).text  # 已经修改完毕
        if item == '登录':
            time.sleep(0.5)
            argument.find_element_by_id(ut['jx_register']['set_password_id']).send_keys(password)
            logger.info(f'输入的账号对应的密码是-->【{password}】')
            argument.find_element_by_id(ut['jx_wallet']['login_id']).click()
            logger.info('单击登录按钮，--->跳转借款页面中......')
            time.sleep(2.0)
            swipe_up(argument, t=500, n=1)  # 弱智程序员，在这个地方跌倒了；六次
            assert_element = argument.find_element_by_id(elements['borrow']['borrow_id']).text
            logger.info('正在验证断言......')  # argument  ==> argument =/= argument 所以报错
            return assert_element
            # argument.assertEqual('我要借款', assert_element, msg="该账号存在、密码与账号相匹配！")
    except:
        """切换账户之后，输入的账号长度小于11位时，此代码运行"""
        time.sleep(1.0)
        logger.info('输入的账号长度小于11位，正在验证断言......')
        element = argument.find_element_by_id(ut['until']['nx_id']).text
        return element
        # argument.assertEqual('下一步', element, msg='账号输入为空、或账号输入长度不够11位')


def fill_in_login(argument, account, code, sms, password):
    """选择更多方式--->选择注册"""
    logger.info('聚焦账号输入框、启用App端自定义键盘、账号输入中......')
    argument.find_element_by_id(ut['jx_register']['phone_id']).click()  #
    for i in Tools.number(account):
        argument.find_element_by_id(ut[i]).click()
    logger.info(f'账号输入完成，输入的账号信息是--->【{account}】')
    time.sleep(1.0)
    argument.find_element_by_id(ut['until']['nx_id']).click()
    logger.info('单击下一步按钮，页面跳转......')
    try:
        time.sleep(1.0)
        element = argument.find_element_by_id(ut['jx_wallet']['login_id']).text
        if element == '登录':
            time.sleep(0.5)
            argument.find_element_by_id(ut['until']['p_id']).send_keys(code)
            logger.info(f'写入的图片验证码是--->【{code}】')
            argument.find_element_by_id(ut['until']['gp_id']).click()
            logger.info('正在获取新的图片验证码......')
            # logger.info('hi')
            argument.find_element_by_id(ut['until']['gs_id']).click()
            logger.info('正在获取手机短信验证码......')
            argument.find_element_by_id(ut['until']['s_id']).send_keys(sms)
            logger.info('已经获取到短信验证码，正在输入短信验证码......')
            argument.find_element_by_id(ut['jx_register']['set_password_id']).send_keys(password)
            logger.info(f'输入的短信验证码是--->【{password}】')
            argument.keyevent(111)  # close keyboard
            logger.info('关闭系统键盘')
            argument.find_element_by_id(ut['until']['nx_id']).click()
    except:
        logger.warning('英俊潇洒的帅哥、美丽动人的美女,测试大佬我技术有限，能输入正常的手机号吗？？？')


def new_account(argument, code, sms, password):
    """this is sign in a new account function"""
    logger.info('start test sign in a new account function.......')
    argument.find_element_by_id(ut['until']['p_id']).send_keys(code)
    logger.info(f'fill in price code is {[code]}')
    argument.find_element_by_id(ut['until']['gp_id']).click()
    logger.info('try get a new price code')
    logger.info('hi')
    argument.find_element_by_id(ut['until']['gs_id']).click()
    logger.info('try get a sms code')
    argument.find_element_by_id(ut['until']['s_id']).send_keys(sms)
    logger.info('get sms code over')
    argument.find_element_by_id(ut['jx_register']['set_password_id']).send_keys(password)
    logger.info(f'fill in sms code is {[password]}')
    argument.keyevent(111)  # close keyboard
    logger.info('close system keyboard')
    argument.find_element_by_id(ut['until']['nx_id']).click()
    logger.info('click sign button, sign a new account test is over!!!')


def login_agreement(argument):
    """verify sign agreement and credit agreement"""
    logger.info('start test sign agreement......')
    argument.find_element_by_id(ut['jx_register']['lx_id']).click()
    time.sleep(2.0)
    argument.get_screenshot_as_file(Tools.cut('login_agreement') + '.png')
    logger.info('screenshots price')
    argument.find_element_by_id(ut['until']['return_id']).click()
    logger.info('touch return button,sign agreement over!!! start test credit agreement.....')
    argument.find_element_by_id(ut['jx_register']['sx_id']).click()
    time.sleep(2.0)
    argument.get_screenshot_as_file(Tools.cut('login_agreement') + '.png')
    logger.info('credit agreement over!!!')


