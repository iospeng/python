# -*- coding: utf-8 -*- 

# @Time : 2018/12/28 下午3:43 

# @Author : 废柴 

# @Project: Jx

# @FileName : MyPage.py 

# @Software: PyCharm

# @Desc : ==============================================

# Life is Short I Use Python!!!                      ===

# If this runs wrong,don't ask me,I don't know why;  ===

# If this runs right,thank god,and I don't know why. ===

# Maybe the answer,my friend,is blowing in the wind. ===

# ======================================================

import time
from Until import logger
from Until import Tools

# ---------------------
#  日志配置
# ---------------------

logger = logger.get_logger('borrow')

# ---------------------
#  页面元素加载
# ---------------------
ac = Tools.info()
bp = Tools.Tools.element('{}/BorrowPage.yaml'.format(ac[-1]))
ut = Tools.Tools.element('{}/Until.yaml'.format(ac[-1]))
my = Tools.Tools.element('{}/MyPage.yaml'.format(ac[-1]))


def feedback(argument, text):
    """我的页面--意见反馈"""
    logger.info('开始测试意见反馈功能....')
    # argument.find_element_by_id(ut['until']['mine_id']).click()
    logger.info('点击我的按钮，等待页面加载')
    argument.find_element_by_id(my['mypage'][4]).click()
    logger.info('点击意见反馈,等待页面加载......')
    time.sleep(1.0)
    item = argument.find_element_by_id(ut['until']['title_id']).text  # 获取当前页面标题

    argument.get_screenshot_as_file(Tools.Tools.cut('feedback') + '.png')
    argument.find_element_by_id(my['feedback'][0]).send_keys(text)
    logger.info(f'输入意见反馈框的内容是：【{text}】')
    # argument.find_element_by_id(my['textnum_id']).text  # 获取输入字数已经剩余可输入字数
    time.sleep(0.5)
    argument.get_screenshot_as_file(Tools.Tools.cut('feedback') + '.png')
    argument.find_element_by_id(my['feedback'][1]).click()  # 单击马上提交按钮
    logger.info('点击提交按钮，测试意见反馈功能结束！')
    return item


# 我的页面 ---> 银行卡类列表 ---> 绑定银行卡
def pay_card(argument, bank_number, sms_code, phone):
    """我的页面--收款银行卡"""
    logger.info("开始测试添加银行卡功能 ......")
    argument.find_element_by_id(ut['until']['mine_id']).click()
    time.sleep(2)
    argument.find_element_by_id(my['mypage'][0]).click()
    logger.info('点击添加收款银行卡按钮')
    time.sleep(10)
    card_list = argument.find_element_by_id(bp['card_list']['card_list_id']).find_elements_by_class_name(
        bp['card_list']['cards_class'])
    logger.info('正在统计用户银行卡数量......')
    if 0 <= (len(card_list) / 2) < 3:
        argument.find_element_by_id(bp['card_list']['add_id']).click()
        logger.info('当前用户已经绑定的银行卡数量小于3张，点击添加银行卡按钮，等待绑定银行卡页面加载......')
        time.sleep(5.0)
    else:
        logger.info('当前绑定的用户银行卡数量大于3张......')
        return "已经绑定了三张银行卡"
    argument.get_screenshot_as_file(Tools.Tools.cut('change_bank_borrow') + '.png')
    # 选择 绑定新的银行卡
    argument.find_element_by_id(bp['card_bind']['bank_id']).click()
    logger.info('点击选择银行按钮，加载银行卡选择列表......')
    time.sleep(1.0)
    # 存在问题 2018-12-21  ---> 待修复
    # argument.find_element_by_id(bp['card_bind']['chose_card_id']).click()
    argument.find_element_by_xpath('//android.view.View[@content-desc="中国工商银行"]').click()
    logger.info('点击工商银行')
    time.sleep(0.5)
    argument.find_element_by_id(bp['card_bind']['card_number_id']).send_keys(bank_number)
    logger.info(f'银行卡输入框填入的数据是【{bank_number}】')
    argument.find_element_by_id(bp['card_bind']['phone_number_id']).send_keys(phone)
    logger.info(f'手机号输入框填入的数据是【{phone}】')
    argument.find_element_by_id(bp['card_bind']['get_sms_id']).click()
    logger.info('点击获取手机短信验证码按钮')
    time.sleep(0.5)
    argument.find_element_by_id(bp['card_bind']['code_id']).send_keys(sms_code)
    logger.info(f'验证码输入框填入的数据是【{sms_code}】')
    argument.keyevent(111)
    argument.find_element_by_id(bp['card_bind']['submit_id']).click()
    logger.info('点击确认绑定按钮')
    time.sleep(0.5)
    argument.get_screenshot_as_file(Tools.Tools.cut('change_bank_borrow') + '.png')


# 我的页面 --->  推荐好友
def recommend_friend(argument, option):
    """我的页面--推荐好友功能"""
    # 0-->QQ 1-->QQ's Zone 2-->WeChat 3--> Circle of friends
    logger.info('开始测试推荐好友功能 ......')
    argument.find_element_by_id(ut['until']['mine_id']).click()
    logger.info('点击我的--->进入我的页面')
    time.sleep(0.5)
    argument.find_element_by_id(my['mypage'][1]).click()
    logger.info('点击推荐好友列表选项')
    argument.get_screenshot_as_file(Tools.Tools.cut('recommend_friend') + '.png')
    # 暂未修改 --- 2018-12-21
    time.sleep(0.5)
    a = argument.find_element_by_class_name(bp['show'][0]).find_elements_by_class_name(bp['show'][1])[1].find_elements_by_class_name(bp['show'][2])
    if option == 0:
        a[1].click()
        logger.info('分享至QQ好友中......')
        time.sleep(2.0)
        argument.get_screenshot_as_file(Tools.Tools.cut('recommend_friend') + '.png')
        try:
            argument.find_element_by_id(ut['system'][1]).click()
        except:
            pass

    elif option == 1:
        a[3].click()
        time.sleep(2.0)
        logger.info('分享至QQ空间中......')
        argument.get_screenshot_as_file(Tools.Tools.cut('recommend_friend') + '.png')
        logger.info('正在写入分享文本......')
        try:
            argument.find_element_by_id(ut['system'][1]).click()  # 点击系统允许按钮
        except:
            pass
        # argument.find_element_by_id(ut['system'][1]).click()
    elif option == 2:
        a[5].click()
        time.sleep(2.0)
        logger.info('分享至微信好友中......')
        argument.get_screenshot_as_file(Tools.Tools.cut('recommend_friend') + '.png')
        try:
            argument.find_element_by_id(ut['system'][1]).click()
        except:
            pass
        # argument.find_element_by_id(ut['system'][1]).click()
    elif option == 3:
        a[7].click()
        time.sleep(2.0)
        logger.info('分享至微信朋友圈中......')
        argument.get_screenshot_as_file(Tools.Tools.cut('recommend_friend') + '.png')
        try:
            argument.find_element_by_id(ut['system'][1]).click()
        except:
            pass
        # argument.find_element_by_id(ut['system'][1]).click()
        logger.info('正在写入分享文本......')
        argument.find_element_by_id('com.tencent.mm:id/cib').send_keys(u'那一年江南月下 你弹琵琶急催我上马，任心事喧哗 你要留下 却不叫我牵挂'
                                                                        u'你说缘如指间沙 握不住就放下，管它风扫落花 赌上一生陪着你挣扎，指间的沙 淹没年华 如今你在哪')
        argument.find_element_by_id('com.tencent.mm:id/j0').click()


def service(argument, options=True, call=True):
    """我的页面---联系客服,当options为True时，测试电话客服功能，为False测试在线客服功能；
    call为False不拨打电话客服电话，为True时拨打电话客服电话
    6点之后在线客服下班将开启留言板功能
    """
    # argument.find_element_by_id(my['mine_id']).click()
    argument.find_element_by_id(my['kefu_id']).click()
    logger.info('开始测试联系客服功能......')
    time.sleep(1.0)
    if options:
        argument.find_element_by_id(my['phonefu_id']).find_elements_by_class_name(my['fu_class'])[
            0].click()  # tel service
        logger.info('点击电话客服选项')
        argument.get_screenshot_as_file(Tools.Tools.cut('service') + '.png')
        if call:
            argument.find_element_by_id(my['call_id']).click()
            logger.info('开始拨打电话客服电话')
        else:
            argument.find_element_by_id(my['callcancel_id']).click()
            logger.info('取消拨打在线客服电话')
    else:
        argument.find_element_by_id(my['phonefu_id']).find_elements_by_class_name(my['fu_class'])[
            1].click()
        logger.info('开始测试在线客服功能......')
        time.sleep(1.0)
        argument.get_screenshot_as_file(Tools.Tools.cut('service') + '.png')


# 因留言板功能只有在客服离开时开启，开启时间不稳定，所以自模块不建议，使用自动化测试
def message_board(argument, text, phone, name, QQ, WeChat):
    logger.info('开始测试在线客服留言板功能......')
    argument.find_element_by_id(my['kf_text_id']).sends(text)
    logger.info(f'向留言板输入的文本是【{text}】')
    logger.info(f'开始记录用户输入的个人信息......')
    msgs = argument.find_element_by_id(my['kf_cml_id']).find_elements_by_class_name[my['kf_cml_class']]
    msgs[0].sends(phone)
    time.sleep(0.5)
    logger.info(f'用户的手机号码是【{phone}】')
    msgs[1].sends(name)
    time.sleep(0.5)
    logger.info(f'用户的姓名是【{name}】')
    msgs[2].sends(QQ)
    time.sleep(0.5)
    logger.info(f'用户的QQ是【{QQ}】')
    msgs[3].sends(WeChat)
    time.sleep(0.5)
    logger.info(f'用户的微信是【{WeChat}】')


def borrow_record(argument):
    """我的页面---借款记录"""
    argument.find_element_by_id(my['borrowrecord_id']).click()
    argument.find_elements_by_class_name(my['record_class'])[0].click()
    time.sleep(5.0)
    argument.get_screenshot_as_file(Tools.Tools.cut('borrow_record') + '.png')
    argument.find_element_by_accessibility_id(my['detial_aid']).click()
    a = argument.title()


def help_center(argument):
    """我的页面---帮助中心"""
    time.sleep(2.0)
    argument.find_element_by_id(my['mypage'][5]).click()
    logger.info('点击帮助中心按钮，等待页面加载......')
    time.sleep(5.0)
    num = 0
    for i in argument.find_element_by_class_name(my['help_center'][0]).find_elements_by_class_name(
            my['help_center'][1]):
        i.click()
        time.sleep(0.5)
        argument.get_screenshot_as_file(Tools.Tools.cut('help_center') + '.png')
        i.click()
        time.sleep(0.5)
        num += 1
    logger.info('问题下拉按钮点击完毕，正在进行截图')
    time.sleep(0.5)
    argument.get_screenshot_as_file(Tools.Tools.cut('help_center') + '.png')
    assert_element = argument.find_element_by_id(ut['until']['title_id']).text
    return assert_element


def msg_center(argument):
    time.sleep(2.0)
    argument.find_element_by_id(my['mypage'][2]).click()
    logger.info('点击消息中心按钮，等待页面元素加载')
    # 我也很无奈啊，它是h5页面加载慢！！！我有什么办法？
    '''
    在不定位toast弹窗的情况下不建议开启 Uiautomator2
    '''
    time.sleep(2.0)
    if argument.find_element_by_id(my['msg'][1]).is_displayed():
        msg = argument.find_element_by_id(my['msg'][1]).find_elements_by_class_name(my['msg'][-1])
    else:
        time.sleep(5.0)
        msg = argument.find_element_by_id(my['msg'][1]).find_elements_by_class_name(my['msg'][-1])
    logger.info('正在加载消息列表......')
    # 每间隔一个为可点击查看消息的元素：

    num = len(msg) / 2
    i = 1
    n = 1
    while n <= num:
        msg[i].click()
        logger.info(f'验证消息{n}，截图保存中')
        time.sleep(2.0)
        argument.keyevent(4)
        i += 2
        n += 1

    argument.keyevent(4)
    logger.info('消息中心验证完成......')


def record(argument):
    time.sleep(1.0)
    try:
        # 判断当前记录中是否存在几款记录，无借款记录则返回'无借款记录字符串'
        record = argument.find_elements_by_id(bp['record'][0])
        # num = sum(record)
        # 点击一个借款记录查看
        record[0].click()
        # h5页面加载等待
        time.sleep(6.0)
    except:
        return '无借款记录'



