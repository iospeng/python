# -*- coding: utf-8 -*- 

# @Time : 2018/12/28 下午3:32 

# @Author : 废柴 

# @Project: Jx

# @FileName : Pay.py 

# @Software: PyCharm

# @Desc : ==============================================

# Life is Short I Use Python!!!                      ===

# If this runs wrong,don't ask me,I don't know why;  ===

# If this runs right,thank god,and I don't know why. ===

# Maybe the answer,my friend,is blowing in the wind. ===

# ======================================================


from Until import logger
from time import sleep
from Until import Tools

# ---------------------
#  日志配置
# ---------------------

logger = logger.get_logger('pay')

# ---------------------
#  页面元素加载
# ---------------------
ac = Tools.info()
pp = Tools.Tools.element('{}/PayPage.yaml'.format(ac[-1]))
bp = Tools.Tools.element('{}/BorrowPage.yaml'.format(ac[-1]))
ut = Tools.Tools.element('{}/Until.yaml'.format(ac[-1]))
my = Tools.Tools.element('{}/MyPage.yaml'.format(ac[-1]))


# 借款页面 ---> 正常还款
def pay(argument):
    """正常还款支付"""
    logger.info('开始测试正常还款功能 .....')
    # 点击我知道了按钮 ----> 若点击不到 ---> 则点击现在就还按钮
    try:
        argument.find_element_by_id(bp['know'][0]).click()
        logger.info('点击借款页面-->我知道了按钮')
    except:
        logger.info('借款页面我知道了按钮已经被点击')
    finally:
        argument.find_element_by_id(bp['know'][1]).click()
        sleep(2)
        logger.info('点击现在就还按钮，页面跳转至还款页面')

    argument.find_element_by_id(pp['order_list'][0]).find_elements_by_class_name(pp['order_list'][1])[-1].click()
    logger.info('点击待还款订单，等待借款详情页面加载.......')
    sleep(10.0)
    argument.find_element_by_accessibility_id(pp['pay_way'][0]).click()
    logger.info('点击立即还款按钮，加载还款方式页面')
    sleep(5)
    argument.find_element_by_class_name(pp['pay_way'][2]).find_element_by_class_name(pp['pay_way'][-1])[1].click()
    logger.info('点击一键还款，加载还款支付页面')
    sleep(5)
    # 暂时未更改 ---> 2018 - 12 - 24
    argument.find_element_by_id(pp['pay'][4]).click()
    logger.info('点击获取短信验证码按钮，等待验证码发送.....')
    sleep(2)
    argument.find_element_by_id(pp['pay'][5]).send_keys('12')
    logger.info(f'短信验证码输入框是【{12}】')
    argument.find_element_by_id(pp['pay'][6]).click()
    # 调用自定义键盘开始输入交易密码
    Tools.keyboard(argument, '123456')
    logger.info(f'交易密码输入完成，交易密码是【 {123456}】')


def renewal(argument):
    """借款后---对借款订单进行续期操作"""
    logger.info('开始测试正常还款功能 .....')
    # 点击我知道了按钮 ----> 若点击不到 ---> 则点击现在就还按钮
    try:
        argument.find_element_by_id(bp['know'][0]).click()
        logger.info('点击借款页面-->我知道了按钮')
    except:
        logger.info('借款页面我知道了按钮已经被点击')
    finally:
        argument.find_element_by_id(bp['know'][1]).click()
        sleep(2)
        logger.info('点击现在就还按钮，页面跳转至还款页面')

    argument.find_element_by_id(pp['order_list'][0]).find_elements_by_class_name(pp['order_list'][1])[-1].click()
    logger.info('点击待还款订单，等待借款详情页面加载.......')
    sleep(10.0)
    argument.find_element_by_accessibility_id(pp['pay_way'][1]).click()
    logger.info('点击申请续期按钮，加载还款方式页面')
    sleep(10.0)
    argument.find_element_by_class_name(pp['pay_way'][2]).find_element_by_class_name(pp['pay_way'][-1])[1].click()
    logger.info('点击一键还款，加载还款支付页面')
    sleep(5)
    # argument.find_element_by_accessibility_id(element['about_renewal_accid']).click()
    # sleep(3.0)
    # logger.info('点击关于续期，等待关于续期页面加载......')
    # 断言用户借贷说明标题--->回退
    argument.find_element_by_id(pp['pay'][6]).click()
    logger.info('点击马上支付按钮，调用系统支付弹窗......')
    # 对交易密码输入框输入交易密码---->支付成功之后跳转至借款详情页面
    Tools.keyboard(argument, '123456')
    # 截图
    argument.get_screenshot_as_file(Tools.Tools.cut('renewal') + '.png')


# 还款页面 ---> 银行卡还款
def card_pay(argument):
    argument.find_element_by_id(pp['pay_type']['type_id']).find_elements_by_id(pp['pay_type']['types_id'])[0].click()
    logger.info('点击银行卡还款推荐按钮，开始测试银行卡还款[推荐]功能，等待还款方式页面加载......')
    sleep(10.0)
    title = argument.find_elements_by_id[ut['until']['title_id']].text
    argument.get_screenshot_as_file(Tools.Tools.cut('card_pay') + '.png')
    argument.find_element_by_id(pp['chose'][0]).click()
    logger.info('收起一键还款，打开到期自动代扣')
    sleep(0.5)
    argument.find_element_by_id(pp['chose'][1]).click()
    sleep(0.5)
    argument.get_screenshot_as_file(Tools.Tools.cut('card_pay') + '.png')
    argument.find_element_by_id(ut['until']['return_id']).click()
    return title


# 还款页面 ---> 更多还款方式
def more_pay_way(argument):
    argument.find_element_by_id(ut['until']['pay_id']).click()
    sleep(1.0)
    argument.find_element_by_id(pp['pay_type']['type_id']).find_elements_by_id(pp['pay_type']['types_id'])[1].click()
    logger.info('点击更多还款方式按钮，开始测试更多还款方式功能，等待还款方式页面加载......')
    sleep(10.0)
    title = argument.find_element_by_id(ut['until']['title_id']).text
    argument.get_screenshot_as_file(Tools.Tools.cut('more_pay_way') + '.png')
    # 检查复制手机号及收款人姓名
    argument.find_element_by_id(pp['chose'][2]).click()
    logger.info('点击复制手机号图标')
    sleep(0.5)
    argument.find_element_by_id(pp['chose'][3]).click()
    logger.info('点击复制姓名图标')
    # 联系电话客服
    # argument.find_elements_by_id(pp['chose'][4]).click()
    logger.info('点击电话客服图标，将拨打电话.....')
    # 联系在线客服
    argument.find_element_by_id(pp['chose'][-1]).click()
    logger.info('点击在线客服图标，进入在线客服')
    sleep(1.0)
    argument.find_element_by_id(my['online'][0]).send_keys('12')
    logger.info(f'输入框写入的内容是{12}')
    argument.find_element_by_id(my['online'][1]).click()
    logger.info(f'点击发送按钮')
    sleep(1.0)
    # 针对发送的内容截图
    argument.get_screenshot_as_file(Tools.Tools.cut('more_pay_way') + '.png')
    argument.find_element_by_id(ut['until']['return_id']).click()
    sleep(1.0)
    argument.find_element_by_xpath('//android.view.View[@content-desc="支付宝还款 "]').click()
    sleep(1.0)
    argument.get_screenshot_as_file(Tools.Tools.cut('more_pay_way') + '.png')
    return title
    # '//android.view.View[@content-desc="支付宝还款 "]'


