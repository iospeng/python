# -*- coding: utf-8 -*- 

# @Time : 2018/12/28 下午3:33 

# @Author : 废柴 

# @Project: Jx

# @FileName : Set_up.py 

# @Software: PyCharm

# @Desc : ==============================================

# Life is Short I Use Python!!!                      ===

# If this runs wrong,don't ask me,I don't know why;  ===

# If this runs right,thank god,and I don't know why. ===

# Maybe the answer,my friend,is blowing in the wind. ===

# ======================================================

import time
from Until import logger
from Until.Tools import Tools, info

# ---------------------
#  日志配置
# ---------------------

logger = logger.get_logger('setup')

# ---------------------
#  页面元素加载
# ---------------------
ac = info()
pp = Tools.element('{}/PayPage.yaml'.format(ac[-1]))
bp = Tools.element('{}/BorrowPage.yaml'.format(ac[-1]))
ut = Tools.element('{}/Until.yaml'.format(ac[-1]))
my = Tools.element('{}/MyPage.yaml'.format(ac[-1]))


# 我的页面 ---> 设置 ---> 检查版本更新
def check_update(argument):

    argument.find_element_by_id(ut['until']['mine_id']).click()
    logger.info('点击我的按钮')
    argument.find_element_by_id(my['setting'][0]).click()
    logger.info('点击app设置按钮')
    logger.info('开始测试检查版本更新功能 ......')
    argument.find_element_by_id(my['setting'][1]).click()
    time.sleep(0.5)
    argument.get_screenshot_as_file(Tools.cut('check_update') + '.png')
    logger.info('测试检查版本更新功能--->结束......')


# 我的页面 ---> 设置 ---> 关于我们
def about_us(argument):

    argument.find_element_by_id(ut['until']['mine_id']).click()
    logger.info('点击我的按钮')
    argument.find_element_by_id(my['setting'][0]).click()
    logger.info('点击app设置按钮')
    logger.info('开始测试关于我们的html5页面')
    argument.find_element_by_id(my['setting'][2]).click()
    time.sleep(5.0)  # wait html5 loading......
    argument.get_screenshot_as_file(Tools.cut('about_us') + '.png')
    # 尝试读取文本信息断言借享钱包名
    title = argument.find_element_by_id(ut['until']['title_id']).text
    print(title)
    return title


# 我的页面 ---> 设置 ---> 修改登录密码
def update_login_password(argument, old_password, new_password1, new_password2):

    argument.find_element_by_id(ut['until']['mine_id']).click()
    logger.info('点击我的按钮')
    argument.find_element_by_id(my['setting'][0]).click()
    logger.info('点击app设置按钮')
    time.sleep(0.5)
    argument.find_element_by_id(my['setting'][3]).click()
    logger.info('点击修改登录密码按钮，开始测试修改登录密码功能 ......')
    # 进入修改登录密码页面
    time.sleep(0.5)
    argument.find_element_by_id(my['change_password_for_login'][1]).send_keys(old_password)
    logger.info(f'旧密码输入框输入的密码是：【{old_password}】')
    argument.find_element_by_id(my['change_password_for_login'][2]).send_keys(new_password1)
    logger.info(f'新密码输入框输入的新密码是：【{new_password1}】')
    argument.find_element_by_id(my['change_password_for_login'][3]).send_keys(new_password2)
    logger.info(f'确认新密码输入框输入的新密码是：【{new_password2}】')
    """
    在不使用'automationName': 'Uiautomator2'配置时，默认使用的时系统键盘。
    启动'automationName': 'Uiautomator2',配置，则使用appium框架的键盘。因此下面的代码需要注释掉
    以下代码注释掉
    argument.keyevent(111)
    logger.info('收起系统键盘')
    time.sleep(0.5)
    """
    argument.find_element_by_id(my['change_password_for_login'][-1]).click()
    logger.info('正在进行断言......')


# 我的页面 ----> 设置 ---> 修改交易密码
def update_pay_password(argument, old_pay_password, new_pay_password1, new_pay_password2):

    # argument.find_element_by_id(ut['until']['mine_id']).click()
    # time.sleep(1.0)
    logger.info('点击我的按钮')
    argument.find_element_by_id(my['setting'][0]).click()
    logger.info('点击app设置按钮')
    time.sleep(1)
    argument.find_element_by_id(my['setting'][-1]).click()
    logger.info('点击修改交易密码, 开始修改交易密码测试.....')
    time.sleep(1.0)
    argument.find_element_by_class_name('android.widget.RelativeLayout').find_element_by_class_name('android.widget.LinearLayout').click()
    # argument.find_elements_by_class_name(ut['pay'][0])[0].click()
    logger.info('聚焦交易密码输入框，开始输入交易密码')
    # 输入密码
    for i in Tools.number(old_pay_password):
        argument.find_element_by_id(ut['until'][i]).click()
    time.sleep(0.5)
    logger.info(f'就密码是密码是【{old_pay_password}】')
    for i in Tools.number(old_pay_password):
        argument.find_element_by_id(ut['until'][i]).click()
    logger.info(f'更新的密码是【{new_pay_password1}】')
    time.sleep(0.5)
    for i in Tools.number(old_pay_password):
        argument.find_element_by_id(ut['until'][i]).click()
    logger.info(f'确认更新的密码是【{new_pay_password2}】')
    """
    敬启后来人：
        后来人，让我来告诉你为什么要写那么多time.sleep，因为接口返回数据时快时慢
    """

    time.sleep(4.0)
    logger.info('进行断言验证中......')


# 我的页面 ---> 设置 ---> 忘记登录密码 --- 忘记登录密码
def forget_login_password(argument, price_code, sms_code, password1, password2):
    """forget login password"""
    logger.info('start test forget login password function ......')
    argument.find_element_by_id(ut['until']['p_id']).send_keys(price_code)
    logger.info(f'输入的图片验证码是： {[price_code]}')
    argument.find_element_by_id(ut['until']['gp_id']).click()
    logger.info('获取新的图片验证码')
    argument.find_element_by_id(ut['until']['gs_id']).click()
    logger.info('获取手机短信验证码')
    argument.find_element_by_id(ut['until']['s_id']).send_keys(sms_code)
    logger.info(f'输入的手机短信验证码是： {[sms_code]}')
    #
    argument.find_element_by_id(ut['until']['nx_id']).click()
    logger.info('点击下一步按钮')
    argument.find_element_by_id(ut['forget_password']['new_password_id']).send_keys(password1)
    logger.info(f'输入的新密码是 {[password1]}')
    argument.find_element_by_id(ut['forget_password']['sure_password_id']).send_keys(password2)
    logger.info(f'输入的确认密码是 {[password2]}')
    argument.find_element_by_id(ut['until']['suerw_id']).click()
    logger.info('点击完成按钮，测试修改忘记登录密码结束！')


#  我的页面 --- 设置 --- 修改交易密码 --- 忘记交易密码
def forget_pay_password(argument, realname, ID, price_code, sms_code, new_pay_password):
    """forget pay password"""
    argument.find_element_by_id(my['find_pay'][0]).send_keys(realname)
    argument.find_element_by_id(my['find_pay'][1]).click()
    for i in Tools.number(ID):
        argument.find_element_by_id(ut['until'][i]).click()
    argument.find_element_by_id(ut['until']['gp_id']).click()
    argument.find_element_by_id(ut['until']['p_id']).send_keys(price_code)
    argument.find_element_by_id(ut['until']['gs_id']).click()
    argument.find_element_by_id(ut['until']['s_id']).send_keys(sms_code)
    argument.find_element_by_id(ut['until']['nx_id']).click()
    argument.find_elements_by_class_name(my['find_pay'][-1])[0].click()
    logger.info('focus pay password input frame')
    for i in Tools.number(new_pay_password):
        argument.find_element_by_id(ut['until'][i]).click()
        logger.info(f'fill in new pay password is {i}')
    argument.find_element_by_id(ut['until']['suerw_id']).click()
    logger.info('test update pay password over!!!')

