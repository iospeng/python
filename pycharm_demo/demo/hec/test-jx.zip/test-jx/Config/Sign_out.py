# -*- coding: utf-8 -*- 

# @Time : 2018/12/28 下午3:33 

# @Author : 废柴 

# @Project: Jx

# @FileName : Sign_out.py 

# @Software: PyCharm

# @Desc : ==============================================

# Life is Short I Use Python!!!                      ===

# If this runs wrong,don't ask me,I don't know why;  ===

# If this runs right,thank god,and I don't know why. ===

# Maybe the answer,my friend,is blowing in the wind. ===

# ======================================================

import time
from Until import logger
from Until.Tools import Tools, info

# ---------------------
#  日志配置
# ---------------------

logger = logger.get_logger('setup')

# ---------------------
#  页面元素加载
# ---------------------

ac = info()
pp = Tools.element('{}/PayPage.yaml'.format(ac[-1]))
bp = Tools.element('{}/BorrowPage.yaml'.format(ac[-1]))
ut = Tools.element('{}/Until.yaml'.format(ac[-1]))
my = Tools.element('{}/MyPage.yaml'.format(ac[-1]))
item = Tools.element('{}/MyPage.yaml'.format(ac[-1]))


def sign_out(argument, option=True):
    """推出登录状态, 默认参数option=True --> 退出App，当option=False --> 取消退出操作"""
    # argument.find_element_by_id(ut['until']['mine']).click()
    argument.find_element_by_id(my['setting'][0]).click()
    time.sleep(1.0)
    argument.find_element_by_id(my['sgin_out'][0]).click()
    argument.get_screenshot_as_file(Tools.cut('sign_out') + '.png')
    time.sleep(1.0)
    if option:
        argument.find_element_by_id(my['sgin_out'][1]).click()
        # 确认退出之后回退到借款首页
        time.sleep(0.5)
        argument.get_screenshot_as_file(Tools.cut('sign_out') + '.png')
    else:
        argument.find_element_by_id(my['sgin_out'][2]).click()
        # 取消退出之后截图
        time.sleep(0.5)
        argument.get_screenshot_as_file(Tools.cut('sign_out') + '.png')

