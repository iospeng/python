# -*- coding: utf-8 -*- 

# @Time : 2019/1/7 下午1:47 

# @Author : 废柴 

# @Project: Jx

# @FileName : JsonExample.py 

# @Software: PyCharm

# @Desc : ==============================================

# Life is Short I Use Python!!!                      ===

# If this runs wrong,don't ask me,I don't know why;  ===

# If this runs right,thank god,and I don't know why. ===

# Maybe the answer,my friend,is blowing in the wind. ===

# ======================================================

"""
将python数据转换为json数据,python与json之间的数据转换演示脚本
"""
import json
data = {
    "president": {
        "name": "Zaphod Beeblebrox",
        "species": "Betelgeusian"
    }
}
# json.dump() 将python数据写入至json文件中
"""with open('example.json', 'w') as fb:
    json.dump(data, fb)"""

# json.load() 将json文件中的数据读取成python中的数据
with open('login_password.json', 'r') as fb:
    info = json.load(fb)

print(info)

datas = {
  "L001":[
    {
      "info":{
        "description":"正确的登录密码,两个正确的新密码",
        "data":{
          "old":"123456",
          "new1":"123456",
          "new2":"123456"
        }
      }
    }
  ],

  "T002":[
    {
      "info":{
        "description":"正确的登录密码,两个新密码不一致",
        "data":{
          "old":"123456",
          "new1":"123456",
          "new2":"654321"
        }
      }
    }
  ],

  "T003":[
    {
      "info":{
        "description":"错误的登录密码,两个正确的新密码",
        "data":{
          "old":"12345678",
          "new1":"123456",
          "new2":"654321"
        }
      }
    }
  ],

  "T004":[
    {
      "info":{
        "description":"登录密码空,两个正确的新密码",
        "data":{
          "old":"",
          "new1":"123456",
          "new2":"654321"
        }
      }
    }
  ],

  "T005":[
    {
      "info":{
        "description":"正确的登录密码,两个新密码中一个空",
        "data":{
          "old":"123456",
          "new1":"",
          "new2":"654321"
        }
      }
    }
  ],

  "T006":[
    {
      "info":{
        "description":"登录密码为空,两个新密码均为空",
        "data":{
          "old":"",
          "new1":"",
          "new2":""
        }
      }
    }
  ],

  "T007":[
    {
      "info":{
        "description":"正确的登录密码,登录密码小于6位",
        "data":{
          "old":"123456",
          "new1":"123",
          "new2":"123"
        }
      }
    }
  ]
}

with open('example.json', 'a') as fb:
    json.dump(datas, fb, ensure_ascii=False)
