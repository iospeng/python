# -*- coding: utf-8 -*- 

# @Time : 2019/1/21 上午11:33 

# @Author : 废柴 

# @Project: TestConfig

# @FileName : settings.py 

# @Software: PyCharm

# @Desc : ==============================================

# Life is Short I Use Python!!!                      ===

# If this runs wrong,don't ask me,I don't know why;  ===

# If this runs right,thank god,and I don't know why. ===

# Maybe the answer,my friend,is blowing in the wind. ===

# ======================================================

import os

# 项目文件
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# 测试数据
DATA_DIR = os.path.join(BASE_DIR, '/Data')
# 定位元素
ELEMENT_DIR = os.path.join(BASE_DIR, '/ElementPage')
# 测试报告
REPORT_DIR = os.path.join(BASE_DIR, '/Report')

# 数据库配置文件
DATABASE_CONFIG = {
    'host': "47.110.72.175",
    'user': "root",
    'password': "wuyun@dm1n",
    'port': 3306
}

APP_CONFIG = {
    'jx': ['com.jxmoney.gringott', '.ui.main.MainActivity'],
    '56': ['com.huiyouqian.gringotts', 'com.jxmoney.gringotts.ui.main.MainActivity'],
    'ylh': ['com.ulinghua.gringotts', 'com.jxmoney.gringotts.ui.main.MainActivity'],
    'wxj': ['com.vxianjin.gringotts', 'com.jxmoney.gringotts.ui.main.MainActivity'],
    'slj': ['com.xianjinduoduo.gringotts', 'com.jxmoney.gringotts.ui.main.MainActivity'],
}
PHONE_CONFIG = {
    'xm': '0',
}





