# -*- coding: utf-8 -*- 

# @Time : 2019/1/7 下午9:59 

# @Author : 废柴 

# @Project: Jx

# @FileName : Excel.py 

# @Software: PyCharm

# @Desc : ==============================================

# Life is Short I Use Python!!!                      ===

# If this runs wrong,don't ask me,I don't know why;  ===

# If this runs right,thank god,and I don't know why. ===

# Maybe the answer,my friend,is blowing in the wind. ===

# ======================================================

# -*-coding:utf-8 -*-
# /usr/bin/env python3
import os
from datetime import date
import xlrd

# ------------------------------
# 读取Excel测试数据
# ------------------------------

DATA_FILE_PATH = os.path.join(os.path.dirname(__file__)).replace('/Until', '/Data/')
print(DATA_FILE_PATH)


class ReadData(object):

    def __init__(self, file_name):
        self.file_name = file_name

    def load_data(self, book_name):
        # 创建一个读取Excel的游标
        b_nonius = xlrd.open_workbook(DATA_FILE_PATH + self.file_name)
        # 读取工作表
        book = b_nonius.sheet_by_name(book_name)



"""book = xlrd.open_workbook("/Users/oldman/excel/test.xlsx")  # 打开excel文件
print(book.sheet_names())
# book.sheet_names()  获取一个excel文件中的所有的excel表，返回的是一个列表
# 获取一个工作表
# 方法一：table = book.sheet_by_index(索引值)
# 方法二：table = book.sheet_by_name(excel的表名字)
# 方法三：table = book.sheets()[索引值]
# 读取整行和整列的数据
table = book.sheets()[0]
line = table.row_values(0)  # 读取某一整行的数据
row = table.col_values(0)  # 返回的是一个列表
print(line)
print(row)
# 获取行数和列数
line_num = table.nrows
row_num = table.ncols
print(line_num, row_num)
# 读取所有行的数据
for i in range(line_num):
    print(table.row_values(i))
# 读取所有列的数据
for i in range(row_num):
    print(table.col_values(i))
# 获取某一单元格的数据
A1 = table.cell(0, 0).value  # 根据列和行定位单元格
print(A1)
# 根据列定位单元格数据，行不变，列变动
row_change = table.row(0)[1].value
print(row_change)
line_change = table.col(0)[2].value
print(line_change)
# python 读取excel中的数据返回五种类型 0：empty，1 string, 2 number, 3 date, 4 boolean, 5 error
print(table.cell(1, 2).value)
item_type = table.cell(1, 2).ctype
print(item_type)
item = xlrd.xldate_as_tuple(table.cell_value(1, 2), book.datemode)
value = date(*item[:3]).strftime('%Y/%d/%m')
print(value)
item_values = xlrd.xldate_as_datetime(table.cell(1, 2).value, book.datemode)
print(item_values)"""
