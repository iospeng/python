# -*- coding: utf-8 -*- 

# @Time : 2019/1/7 下午3:15 

# @Author : 废柴 

# @Project: Jx

# @FileName : SendEmail.py 

# @Software: PyCharm

# @Desc : ==============================================

# Life is Short I Use Python!!!                      ===

# If this runs wrong,don't ask me,I don't know why;  ===

# If this runs right,thank god,and I don't know why. ===

# Maybe the answer,my friend,is blowing in the wind. ===

# ======================================================

"""
邮件发送脚本
"""

import smtplib
from email.header import Header
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.header import Header
from email.utils import formataddr

"""发件者邮件服务器地址"""
SERVER = "smtp.sina.com"
"""发件者邮寄服务器端口号"""
PORT = 25
"""发件者邮箱"""
SENDER = "benkint@sina.com"
"""发件者邮箱密码或授权码"""
PASSWORD = "oldman"
"""收件者邮箱"""
RECEIVER = "78982035@qq.com"


class SendEmail(object):

    def __init__(self):
        """初始化配置文件，"""
        self.theme = Header("来自测试大哥的测试报告", 'utf-8').encode()  # 设置邮件头部信息
        self.smtp = smtplib.SMTP(host=SERVER, port=PORT)  # 连接发件者邮件服务器
        self.smtp.login(user=SENDER, password=PASSWORD)  # 登录发件者邮箱

    def write_text(self, affix=False):

        if affix:
            msg = MIMEMultipart()
            msg['From'] = formataddr(["发件人邮箱", SENDER])
            msg['To'] = formataddr(["收件人邮箱", RECEIVER])
            msg['Subject'] = self.theme
            msg.attach(MIMEText("正文", "plain", "utf-8"))
        else:
            msg = MIMEText("第二版本--->正文，哈哈哈", 'plain', 'utf-8')
            msg['From'] = formataddr(["发件人邮箱", SENDER])
            msg['To'] = formataddr(["收件人邮箱", RECEIVER])
            msg['Subject'] = self.theme
        return msg

    def affix(self):
        with open("文件", "rb") as fb:
            fb.read()

    def send_email(self):
        self.smtp.sendmail(from_addr=SENDER, to_addrs=[RECEIVER], msg=self.write_text().as_string())
        self.smtp.quit()

    def main(self):
        self.send_email()


if __name__ == '__main__':
    go = SendEmail()
    go.main()
