# -*- coding: utf-8 -*- 

# @Time : 2019/1/7 下午9:57 

# @Author : 废柴 

# @Project: Jx

# @FileName : T1.py 

# @Software: PyCharm

# @Desc : ==============================================

# Life is Short I Use Python!!!                      ===

# If this runs wrong,don't ask me,I don't know why;  ===

# If this runs right,thank god,and I don't know why. ===

# Maybe the answer,my friend,is blowing in the wind. ===

# ======================================================

from bottle import run, get, request
import time
from datetime import timedelta
import requests

"""
更改逾期、放款、辅助工具、后期将使用django Web框架直接优化，尽可能将凯哥的接口请求移植到Django中
"""

# Mysql数据库配置信息
HOST = "47.110.72.175"
USER = "root"
PASSWORD = "wuyun@dm1n"
PORT = 3306

# 使用表sql
USER_BW = "use qbm_server;"

# Redis数据库配置信息
RD_HOST = "localhost"
RD_PORT = 6379
# 逾期测试job
# URL = 'http://118.31.73.40:8083/back/overdue'  # 速来借逾期
# URL = 'http://47.99.203.25:8083/back/overdue'  # 56钱包逾期
URL = "http://47.98.200.113:8083/back/overdue"  # 借享逾期
# URL = "http://47.98.240.102:8083/back/overdue"  # 有零花逾期
# URL = "http://47.99.87.200:8083/back/overdue"  # 微现金逾期


class DataMysql(object):

    def __init__(self):
        self.my = pymysql.connect(user=USER, password=PASSWORD, port=PORT, host=HOST, charset="utf8")
        self.cr = self.my.cursor()
        self.cr.execute(USER_BW)

    def data_delete(self, user_name):
        """删除账号所有的信息"""
        sql1 = f"select id from user_info where user_name = {user_name}"  # 获取用户user_id
        self.cr.execute(sql1)
        user_id = self.cr.fetchone()[0]
        sql_list = [
            f"delete from user_info where user_name = {user_name}",

            f"delete from info_index_info where user_id = {user_id}",

            f"delete from user_card_info  where user_id = {user_id}",

            f"delete from `asset_borrow_order` where user_id = {user_id}",

            f"delete from `asset_repayment` where user_id = {user_id}",

            f"delete from `asset_repayment_detail` where user_id = {user_id}",

            f"delete from `order_change_log` where user_id = {user_id}",

            f"delete from `user_borrowquota_snapshot` wher user_id = {user_id}",

            f"delete from `user_creditquota_log` where user_id = {user_id}",

            f"delete from `user_quota_apply_fail_log` where user_id = {user_id}",
        ]
        # 逐条执行清空数据sql
        for item in sql_list:
            self.cr.execute(item)
        self.my.close()
        return f"{user_name}数据清空完毕"

    def yi_info(self, user_name):
        """查询用户user_id和最近的一笔订单"""
        sql1 = f"select id from user_info where user_name = {user_name}"
        self.cr.execute(sql1)
        user_id = self.cr.fetchone()[0]
        sql2 = f'select id from `asset_borrow_order` where user_id = {user_id} order by id desc limit 1'
        self.cr.execute(sql2)
        borrow_id = self.cr.fetchone()[0]
        print(borrow_id)
        self.my.close()
        return (user_id, borrow_id)

    def overdue(self, user_name, day):
        """更改逾期的数据"""
        sql1 = f"select id from user_info where user_name = {user_name}"
        self.cr.execute(sql1)
        user_id = self.cr.fetchone()[0]
        self.cr.execute(f'select id, created_at from `asset_repayment` where user_id = {user_id} order by id desc limit 1')
        info = self.cr.fetchone()
        today = info[1].date()
        overdue_time = (today + timedelta(days=-day)).strftime("%Y-%m-%d")
        print(overdue_time)
        sql2 = f"update `asset_repayment` set `repayment_time` = '{overdue_time} 12:00:00', status = '-11' where id = {info[0]}"
        self.cr.execute(sql2)
        self.my.commit()
        self.my.close()


class DataRedis(object):

    def __init__(self):

        pool = redis.ConnectionPool(host=RD_HOST, port=RD_PORT, db=0, decode_responses=True)
        self.rd = redis.Redis(connection_pool=pool)

    def data_wr(self, key, value):
        self.rd.set(name=key, value=value)
        print("data write into redis over")

    def data_rd(self, key):

        data = self.rd.get(name=key)
        return data


@get('/delete_data/')
def delete():
    """一键清空测试环境的账号数据"""
    use_mysql = DataMysql()
    user_name = request.query['username']
    use_mysql.data_delete(user_name)
    return user_name


@get('/yi/')
def yi():
    """一键放款"""
    use_mysql = DataMysql()
    user_name = request.query['username']
    info = use_mysql.yi_info(user_name=user_name)  # project: slj、jx、ulinghua、wlqb、vxj， env：a（测试环境放款） y(预上线环境放款)
    req = requests.get(f'http://192.168.2.113:8081/test?userId={info[0]}&borrowId={info[1]}&project=jx&env=a')
    values = req.content.decode('utf-8')
    time.sleep(1)
    a = requests.get(values)
    return a.content.decode('utf-8')


@get('/overdue/')
def overdue():
    """一键逾期"""
    use_mysql = DataMysql()
    user_name = request.query['username']
    day = request.query['day']
    use_mysql.overdue(user_name, int(day))
    requests.get(URL)
    return f'{user_name}逾期数据修改完成！'


run(host='192.168.2.65', port=8000)
