# -*- coding: utf-8 -*- 

# @Time : 2018/12/28 下午3:35 

# @Author : 废柴 

# @Project: Jx

# @FileName : Tools.py 

# @Software: PyCharm

# @Desc : ==============================================

# Life is Short I Use Python!!!                      ===

# If this runs wrong,don't ask me,I don't know why;  ===

# If this runs right,thank god,and I don't know why. ===

# Maybe the answer,my friend,is blowing in the wind. ===

# ======================================================

import re
import time
import yaml
import requests
import unittest
from TestConfig.settings import *
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from HTMLTestRunner_Chart import HTMLTestRunner


class Tools(object):
    __URL = "http://192.168.1.111:8080/a"  # 手机端开启bottle服务，此URL为手机端的IP地址
    __code_num = []  # 定义一个储存短信的列表容器

    def get_code(self):
        """自动获取手机登录短信验证码;非易宝支付验证码"""
        response = requests.get(self.__URL)
        sms = response.content.decode('utf-8')
        ma = re.findall(r"{(.*?)}", sms, re.S)  # 获取每条的短息内容
        for i in ma:
            # pay = re.findall(r"'body': '(.*?) 支付验证码,", i, re.S)
            # pay1 = re.findall(r"】(.*?) 支付验证码,", i,re.S)
            code1 = re.findall(r"本次验证码为(.*?)有效时间5分钟", i, re.S)  # 登录注册、后台server验证码
            code2 = re.findall(r"尊敬的用户，本次验证码为(.*?)请勿泄露，", i, re.S)  # 忘记修改、登录交易密码验证码

            if code1:
                self.__code_num.append(code1[0])
            elif code2:
                self.__code_num.append(code2[0])
        return self.__code_num[0]

    @staticmethod
    def number(num):
        """custom virtual keyboard，num type: int"""
        return [f'n{i}_id' for i in num]

    def report_name(self):

        cur_time = time.strftime("%Y-%m-%d")  # -%H:%M:%S
        report_path = os.path.join(os.path.dirname(__file__)).replace('Until', 'Report/') + cur_time + '.html'
        return report_path

    def html_report(self, class_name, title, description):
        suite = unittest.TestSuite()
        suite.addTests(unittest.TestLoader().loadTestsFromTestCase(class_name))
        with open(self.report_name(), 'wb') as fb:
            runner = HTMLTestRunner(
                stream=fb,
                title=title,
                description=description,
                verbosity=2,
                retry=0,
                save_last_try=True,
            )
            runner.run(suite)

    @staticmethod
    def element(var):
        """读取定位元素文件方法---加载ElementPage目录下的各个马甲包文件定位文件名"""
        config_yml = os.path.join(os.path.dirname(__file__)).replace('Until', 'ElementPage/') + var
        with open(config_yml) as fb:
            temp = yaml.load(fb.read())
        return temp

    @staticmethod
    def cut(fuc_name):
        """定义截图名称"""
        screenshots = os.path.join(os.path.dirname(__file__)).replace('Until', 'Report/screenshots/')
        test_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
        price_name = screenshots + fuc_name + '-' + test_time
        return price_name

    @staticmethod
    def go_back(argument, n=1):
        """

        :param argument: self.driver
        :param n: 后退次数
        :return: None
        """
        for i in range(n):
            argument.keyevent(4)  # 使用回退按钮回退
            time.sleep(0.5)


def swipe_up(argument, t=500, n=2):
    """向上滑动屏幕"""
    size = argument.get_window_size()
    # size = argument.get
    x1 = size['width'] * 0.5  # x坐标 50
    y1 = size['height'] * 0.25  # 起始y坐标 50
    y2 = size['height'] * 0.75  # 150
    for i in range(n):
        argument.swipe(x1, y2, x1, y1, t)


def swipe_down(argument, t=500, n=2):
    """向下滑动屏幕"""
    size = argument.get_window_size()
    x1 = size['width'] * 0.5  # x坐标
    y1 = size['height'] * 0.25  # 起始y坐标
    y2 = size['height'] * 0.75
    for i in range(n):
        argument.swipe(x1, y1, x1, y2, t)


def swipe_left(argument, t=500, n=2):
    """向左滑动屏幕"""
    size = argument.get_window_size()
    x1 = size['width'] * 0.5  # x坐标
    x2 = size['width'] * 0.25  # 起始y坐标
    y1 = size['height'] * 0.75
    for i in range(n):
        argument.swipe(x1, y1, x2, y1, t)


def swipe_right(argument, t=500, n=2):
    """向右滑动屏幕"""
    size = argument.get_window_size()
    x1 = size['width'] * 0.5  # x坐标
    x2 = size['height'] * 0.25  # 起始y坐标
    y1 = size['height'] * 0.75
    for i in range(n):
        argument.swipe(x2, y1, x1, y1, t)


def keyboard(argument, num):

    """The original keyboard"""
    keys = {
        '0': 7,
        '1': 8,
        '2': 9,
        '3': 10,
        '4': 11,
        '5': 12,
        '6': 13,
        '7': 14,
        '8': 15,
        '9': 16,
        'A': 17,
        'B': 18,
        'C': 31,
        'D': 32,
        'E': 32,
        'F': 34,
        'G': 35,
        'H': 36,
        'I': 37,
        'J': 38,
        'K': 39,
        'L': 40,
        'M': 41,
        'N': 42,
        'O': 43,
        'P': 44,
        'Q': 45,
        'R': 46,
        'S': 47,
        'T': 48,
        'U': 49,
        'V': 50,
        'W': 51,
        'X': 52,
        'Y': 53,
        'Z': 54,
    }
    try:
        for i in num:
            argument.keyevent(keys[i])
    except TypeError:
        print('传入的参数类型必须是int类型')


# 返回借款首页函数
def go_borrow(argument, num):
    """ num 代表点击左上角返回键的次数"""
    time.sleep(0.5)
    for i in range(num):
        argument.keyevent(4)
    # argument.find_element_by_id('com.jxmoney.gringotts:id/rb_len').click()  # 回到借款页面


def is_toast(argument, toast_text,):
    """
    判断是否存在toast弹窗消息，此方法不是非常稳定
    :param argument: 传入self.driver
    :param toast_text: toast文本的内容，例如："再按一次退出程序"
    :return: False or True
    """
    try:
        toast_loc = ("xpath", f".//*[contains(@text,'{toast_text}')]")
        WebDriverWait(argument, 2, 0.1).until(EC.presence_of_element_located(toast_loc))
        return True
    except:
        return False


def is_element(argument, element, t=1.0):
    """
    判断一个元素是否加载出来，若未加载到，则执行sleep，仅用于可点击元素加载后的点击操作
    :param argument: self.driver
    :param element: 定位元素
    :param t: sleep time
    :return: None
    """
    if argument.find_element_by_id(element).is_displayed():
        argument.find_element_by_id(element).click()
    else:
        time.sleep(t)
        argument.find_element_by_id(element).click()


def app_config(var):
    config_yml = os.path.join(os.path.dirname(__file__)).replace('Until', 'Config/Base/') + var
    with open(config_yml) as fb:
        temp = yaml.load(fb.read())
    return temp


def info():
    # 根据TestConfig目录下的settings.yaml测试手机配置文件选择配置文件
    with open(os.path.join(BASE_DIR, 'TestConfig/settings.yaml'),  'r') as fb:
        settings = yaml.load(fb)
    desc = [
        settings['device_id'],
        settings['version'],
        APP_CONFIG[settings['app']],
        settings['app'],
    ]
    return desc


"""  
def swipeDown(driver, t=500, n=1):
    '''向下滑动屏幕'''
    l = driver.get_window_size()
    x1 = l['width'] * 0.5          # x坐标
    y1 = l['height'] * 0.25        # 起始y坐标
    y2 = l['height'] * 0.75         # 终点y坐标
    for i in range(n):
        driver.swipe(x1, y1, x1, y2,t)
swipe(self, start_x, start_y, end_x, end_y, duration=None) 
    Swipe from one point to another point, for an optional duration.
    从一个点滑动到另外一个点，duration是持续时间

    :Args:
    - start_x - 开始滑动的x坐标
    - start_y - 开始滑动的y坐标
    - end_x - 结束点x坐标
    - end_y - 结束点y坐标
    - duration - 持续时间，单位毫秒

    :Usage:
    driver.swipe(100, 100, 100, 400)
"""

"""
电话键

KEYCODE_CALL 拨号键 5
KEYCODE_ENDCALL 挂机键 6
KEYCODE_HOME 按键Home 3
KEYCODE_MENU 菜单键 82
KEYCODE_BACK 返回键 4
KEYCODE_SEARCH 搜索键 84
KEYCODE_CAMERA 拍照键 27
KEYCODE_FOCUS 拍照对焦键 80
KEYCODE_POWER 电源键 26
KEYCODE_NOTIFICATION 通知键 83
KEYCODE_MUTE 话筒静音键 91
KEYCODE_VOLUME_MUTE 扬声器静音键 164
KEYCODE_VOLUME_UP 音量增加键 24
KEYCODE_VOLUME_DOWN 音量减小键 25

控制键

KEYCODE_ENTER 回车键 66
KEYCODE_ESCAPE ESC键 111
KEYCODE_DPAD_CENTER 导航键 确定键 23
KEYCODE_DPAD_UP 导航键 向上 19
KEYCODE_DPAD_DOWN 导航键 向下 20
KEYCODE_DPAD_LEFT 导航键 向左 21
KEYCODE_DPAD_RIGHT 导航键 向右 22
KEYCODE_MOVE_HOME 光标移动到开始键 122
KEYCODE_MOVE_END 光标移动到末尾键 123
KEYCODE_PAGE_UP 向上翻页键 92
KEYCODE_PAGE_DOWN 向下翻页键 93
KEYCODE_DEL 退格键 67
KEYCODE_FORWARD_DEL 删除键 112
KEYCODE_INSERT 插入键 124
KEYCODE_TAB Tab键 61
KEYCODE_NUM_LOCK 小键盘锁 143
KEYCODE_CAPS_LOCK 大写锁定键 115
KEYCODE_BREAK Break/Pause键 121
KEYCODE_SCROLL_LOCK 滚动锁定键 116
KEYCODE_ZOOM_IN 放大键 168
KEYCODE_ZOOM_OUT 缩小键 169

组合键

KEYCODE_ALT_LEFT Alt+Left
KEYCODE_ALT_RIGHT Alt+Right
KEYCODE_CTRL_LEFT Control+Left
KEYCODE_CTRL_RIGHT Control+Right
KEYCODE_SHIFT_LEFT Shift+Left
KEYCODE_SHIFT_RIGHT Shift+Right

基本

KEYCODE_0 按键'0' 7
KEYCODE_1 按键'1' 8
KEYCODE_2 按键'2' 9
KEYCODE_3 按键'3' 10
KEYCODE_4 按键'4' 11
KEYCODE_5 按键'5' 12
KEYCODE_6 按键'6' 13
KEYCODE_7 按键'7' 14
KEYCODE_8 按键'8' 15
KEYCODE_9 按键'9' 16
KEYCODE_A 按键'A' 29
KEYCODE_B 按键'B' 30
KEYCODE_C 按键'C' 31
KEYCODE_D 按键'D' 32
KEYCODE_E 按键'E' 33
KEYCODE_F 按键'F' 34
KEYCODE_G 按键'G' 35
KEYCODE_H 按键'H' 36
KEYCODE_I 按键'I' 37
KEYCODE_J 按键'J' 38
KEYCODE_K 按键'K' 39
KEYCODE_L 按键'L' 40
KEYCODE_M 按键'M' 41
KEYCODE_N 按键'N' 42
KEYCODE_O 按键'O' 43
KEYCODE_P 按键'P' 44
KEYCODE_Q 按键'Q' 45
KEYCODE_R 按键'R' 46
KEYCODE_S 按键'S' 47
KEYCODE_T 按键'T' 48
KEYCODE_U 按键'U' 49
KEYCODE_V 按键'V' 50
KEYCODE_W 按键'W' 51
KEYCODE_X 按键'X' 52
KEYCODE_Y 按键'Y' 53
KEYCODE_Z 按键'Z' 54
"""
