# -*- coding: utf-8 -*- 

# @Time : 2018/12/28 下午3:35 

# @Author : 废柴 

# @Project: Jx

# @FileName : logger.py 

# @Software: PyCharm

# @Desc : ==============================================

# Life is Short I Use Python!!!                      ===

# If this runs wrong,don't ask me,I don't know why;  ===

# If this runs right,thank god,and I don't know why. ===

# Maybe the answer,my friend,is blowing in the wind. ===

# ======================================================

import os
import datetime
import logging

# ----------------------
# 日志脚本配置区域
# ----------------------

logs = os.path.join(os.path.dirname(__file__).replace('Until', 'Logs/'), str(datetime.datetime.now().date()) + ".out")
formatter = logging.Formatter(fmt='%(asctime)s,%(msecs)d %(levelname)-4s [%(filename)s:%(lineno)d] %(message)s',
                              datefmt='%d-%m-%Y:%H:%M:%S')
con_handler = logging.StreamHandler()
con_handler.setFormatter(formatter)
fil_handler = logging.FileHandler(logs, encoding='utf-8')
fil_handler.setFormatter(formatter)


def get_logger(name):
    logger = logging.getLogger(name)
    logger.addHandler(con_handler)
    logger.addHandler(fil_handler)
    logger.setLevel(logging.INFO)
    return logger

