# -*- coding: utf-8 -*- 

# @Time : 2019/1/21 上午10:07 

# @Author : 废柴 

# @Project: TestConfig

# @FileName : manage.py 

# @Software: PyCharm

# @Desc : ==============================================

# Life is Short I Use Python!!!                      ===

# If this runs wrong,don't ask me,I don't know why;  ===

# If this runs right,thank god,and I don't know why. ===

# Maybe the answer,my friend,is blowing in the wind. ===

# ======================================================

"""
管理测试脚本
目的根据不同测试手机、app马甲包，实现选择配置---自动运行脚本
"""
import yaml

from TestConfig.settings import *
from Until import ADB

TEST_APP_NAME = input('测试马甲的英文简写')
TEST_PHONE_NAME = input('测试手机')
SETTINGS_FILE = os.path.join(BASE_DIR, 'TestConfig/settings.yaml')

# 验证测试机信息
if TEST_PHONE_NAME in PHONE_CONFIG:
    if TEST_APP_NAME in APP_CONFIG:
        status = ADB.ADB().get_status()
        if status is '手机设备与PC连接正常':
            print(status)
        else:
            print(status)
    else:
        print('马甲信息与初始设置不匹配，请参阅如下信息重新配置：\n{}'.format(APP_CONFIG))
else:
    print('手机信息与初始设置不匹配，请参参阅如下信息重新配置：\n{}'.format(PHONE_CONFIG))


# 获取已连接测试机的序列号

device_id = ADB.ADB().get_device_id()   # 获取手机的序列号
version = ADB.ADB().get_android_version()   # 获取手机系统的当前版本

config = {
    'app': TEST_APP_NAME,
    'device': TEST_PHONE_NAME,
    'device_id': device_id,
    'version': version,
}

# 将手机设备数据写入测试项目配置文件
with open(SETTINGS_FILE, 'w') as fb:
    fb.write(yaml.dump(config))


# --------------------------------- 梦想分割线 ------------------------------------
# 参考代码一

# with open('eg.yaml', 'r') as fb:
#     y = yaml.load(fb)
#     print(yaml.load(fb))
#
# with open('eg.yaml', 'w') as fb:
#     fb.write(yaml.dump(y))


