# -*- coding: utf-8 -*-
#!/usr/bin/python

import requests
import json
from dingwei import pa
from bs4 import BeautifulSoup
import lxml
import re
import time

'''
使用request、beautifulSop、re 三方库，爬虫 
爬取指定网址的文章、图片

'''

class craw(object):
    # def __init__(self):
        # self.dw = pa()
        # self.dw.text_lib()
    def request_baidu(self):
        # request = requests.post()
        # url = self.dw.p_url()
        ss = 'https://www.qiushibaike.com/'
        res = requests.get(ss)
        con = res.text
        # 将抓取到的网页数据放入BeautifulSoup中
        soup = BeautifulSoup(con, 'lxml')
        # 找到所有class为“article block untagged mb15 typs_hot”的控件
        divs_list = soup.find_all(class_='article block untagged mb15 typs_long')
        list_all = ['article block untagged mb15 typs_hot',
                    'article block untagged mb15 typs_recent',
                    'article block untagged mb15 typs_old']
        for lists in list_all:
            # divs_list3.extend()
            divs_list.extend(soup.find_all(class_=lists))

        # print(divs_list)
        print('个数：', len(divs_list))

        # 打开文件
        fileOpen = open("D:\demo\pachong.txt","w+",encoding='utf-8')
        for div in divs_list:
            if div.find(div='thumb'):
                returns
            d = div.find(class_='contentHerf')
            d2 = d.find(class_='content')
            texts = d2.span.get_text()
            # 将爬取到的数据写入txt文件
            fileOpen.write(texts)
            # print(texts)
            # 关闭文件
        fileOpen.close()
        s = 0
        #下载图片
        for dv in divs_list:
            # if not dv.find(div='thumd'):
            #     return
            img = dv.find('img')
            imgurl = img.get('src')
            str =re.match(r'.*?\?',imgurl)
            imgstr = str.group()
            # 拼接图片地址
            newurl = 'http:'+imgstr[:-1]
            #下载图片
            Dowimg = requests.get(newurl)
            s = s+1
            #下载路径拼接
            pathurl = 'D:\demo\img\\'+'%d'%s+'.jpg'

            with open(pathurl,'wb') as dowpath:
                dowpath.write(Dowimg.content)
                dowpath.flush()
            dowpath.close()
            print('第%d张图片下载完成'%s)
            time.sleep(1)
if __name__=="__main__":
    cr = craw()
    cr.request_baidu()
