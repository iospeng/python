from selenium import webdriver
import time

class pa(object):
    @classmethod
    def __init__(self):
        # 创建web对象，指定浏览器
        self.driver = webdriver.Chrome()
        # 浏览器最大化
        self.driver.maximize_window()
        self.url = 'http://www.sjq.cn/'
        self.pUrl = 0
    # 定位输入框
    def text_lib(self):
        self.driver.get(self.url)
        time.sleep(2)
        self.driver.find_element_by_name("keywords").send_keys('衬衫')
        time.sleep(2)
        # self.driver.find_element_by_id('su').click()
        self.driver.find_element_by_class_name('ecsc-search-button').click()
        self.pUrl = self.driver.current_url
        # print(self.pUrl)
    def p_url(self):
        return self.pUrl
