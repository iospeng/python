from selenium import webdriver
import unittest
import time
from log import sjq

# log = sjq()
class jies(unittest.TestCase):

    def __init__(self,test):
        self.dr = sjq()
        self.test = test

    def test_loan(self):

        self.dr.driver.find_element_by_xpath('/html/body/div[1]/div[1]/div[2]/ul/li[5]/a').click()
        time.sleep(2)