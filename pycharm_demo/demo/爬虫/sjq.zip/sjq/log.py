
from selenium import webdriver
import unittest
import time

class sjq(unittest.TestCase):
    '''
                使用 “classmethod” 修饰符修饰 “setUpClass” 方法，
                这样 “setUpClass” 方法仅运行一次，
                “setUpClass” 方法和 “classmethod”并存，必须一起使用
                “setUp”方法运行多次

     '''

    @classmethod
    def setUpClass(cls):
        cls.driver = webdriver.Chrome()
        cls.url = 'http://116.62.40.106:8081/back/login'

    @classmethod
    def tearDownClass(cls):
        pass

    def login(self,name,password):
        u'''登录'''                       #生成HTML格式的测试报告，在测试用例名称后面追加中文名字
        # 使用设置的浏览器打开初始网址
        self.driver.get(self.url)

        self.driver.find_element_by_xpath('//*[@id="userMobile"]').send_keys(name)
        time.sleep(2)
        self.driver.find_element_by_xpath('//*[@id="userPassword"]').send_keys(password)
        time.sleep(2)
        self.driver.find_element_by_xpath('//*[@id="captcha"]').send_keys(input())
        time.sleep(2)
        self.driver.find_element_by_xpath('//*[@id="sendCode"]').click()
        time.sleep(2)

        ''' 
                switch_to_alert() 　　#定位弹出对话
                text() 　　                #获取对话框文本值
                accept()                   #相当于点击"确认"
                dismiss()                  #相当于点击"取消"
                send_keys()              # 输入值，这个alert和confirm没有输入对话框，所以这里就不能用了，所以这里只能使用在prompt这里。
        '''

        # 获取对话框
        alert = self.driver.switch_to_alert()
        # time.sleep(2)
        # 对话框是警告对话框，只能接受（确定）弹窗
        alert.accept()
        time.sleep(2)
        self.driver.find_element_by_xpath('//*[@id="smsCode"]').send_keys(input())
        time.sleep(2)
        self.driver.find_element_by_xpath('/html/body/div/form/table/tbody/tr/td/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[5]/td/input').click()
        time.sleep(2)

    def test_a1login(self):
        u'''用户名、密码正确'''
        self.login('13552362190','tql')
        enxt = self.driver.find_element_by_xpath('/html/body/div[1]/div[1]/div[1]/ul[1]/li[4]/a')
        time.sleep(2)
        self.assertEqual('退出',enxt.text)

    def test_a2login(self):
        u'''用户名、密码错误'''
        self.login('123','12344')
        enxt = self.driver.find_element_by_xpath('/html/body/div[1]/div[1]/div[1]/ul[1]/li[4]/a')
        time.sleep(2)
        # 获取对话框
        alert = self.driver.switch_to_alert()
        # time.sleep(2)
        # 对话框是警告对话框，只能接受（确定）弹窗
        enxt = alert.text()
        time.sleep(2)
        self.assertEqual('该用户不存在',enxt)
        alert.accept()

    def test_bsou(self):
        u'''用户信息管理'''
        self.driver.find_element_by_xpath('/html/body/div[1]/div[1]/div[2]/ul/li[4]/a').click()
        time.sleep(2)

    def test_cxuan(self):
        u'''用户实名认证列表'''
        self.driver.find_element_by_xpath('/html/body/div[1]/div[2]/div[2]/div/div[2]/ul/li[4]/div/a').click()
        time.sleep(2)
    # 搜索身份证号
    def test_dnumber(self):
        u'''搜索身份证号'''
        self.driver.find_element_by_xpath('/html/body/div[1]/div[3]/div/div[2]/div[2]/form/div[1]/div/table/tbody/tr/td[3]/input').send_keys('420683199509090938')
        time.sleep(2)
        self.driver.find_element_by_xpath('/html/body/div[1]/div[3]/div/div[2]/div[2]/form/div[1]/div/table/tbody/tr/td[4]/div/div/button').click()
        time.sleep(2)

