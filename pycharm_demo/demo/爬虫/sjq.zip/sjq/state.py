
from selenium import webdriver
import HTMLTestRunner
import unittest                 #生成测试用例所依赖的父类unittest.TestCase
import time
from log import sjq
# from jie import jies



if __name__ == '__main__':
    # 项目路径
    path = 'D:\demo\sjq'
    # 创建保存测试用例的对象  unittest.defaultTestLoader.discover(项目路径，项目启动文件)
    test_dis = unittest.defaultTestLoader.discover(path,pattern='state.py')
    # 定义单元测试（测试用例）容器
    # test = unittest.TestSuite()
    # 将测试用例放到容器中
    # test.addTest(sjq('test_alogin'))
    # test.addTest(sjq('test_bsou'))
    # test.addTest(sjq('test_cxuan'))
    # test.addTest(sjq('test_dnumber'))
    # test.addTest(jies('test_loan'))
    unittest.main()

    # 一次性将该类下的全部用例加入容器中
    # test = unittest.makeSuite(Borrow)

    # 保存测试用例路径
    save = 'D:\\demo\\error\\borrow.html'
    # 打开保存报告的HTML文件
    fp = open(save,'wb')
    # 保存报告
    runner = HTMLTestRunner.HTMLTestRunner(stream=fp,title='借享后台测试报告',description='借享后台测试报告')
    runner.run(test_dis)
    fp.close()