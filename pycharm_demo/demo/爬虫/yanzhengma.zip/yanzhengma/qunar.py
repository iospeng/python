
import requests
from bs4 import BeautifulSoup
import lxml

import pytesseract
from PIL import Image

def qunar():
    url = 'https://user.qunar.com/passport/login.jsp?ret=https%3A%2F%2Fwww.qunar.com%2F%3Ftab%3Dhotel%26ex_track%3Dauto_4e0d874a'
    # 访问登录页
    sess = requests.session()
    get_ma = sess.post(url)
    s = get_ma.cookies._cookies
    # print(get_ma.cookies._cookies)
    bls = BeautifulSoup(get_ma.text,'lxml')

    img = bls.find(id='vcodeImg')
    # print(img)
    img_url = img.get('src')

    dowimg = sess.get(img_url)

    # 下载验证码
    lujin = 'D:\demo\img\qunar.jpg'
    dowpath = open(lujin,'wb')
    dowpath.write(dowimg.content)
    dowpath.close()

    # 自动识别验证码
    # pytesseract.pytesseract.tesseract_cmd='C:\Program Files\Tesseract-OCR\tesseract'
    # pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
    images = Image.open(lujin)
    vcode = pytesseract.image_to_string(images)
    print('自动识别验证码信息：',vcode)

    # 验证码
    # print('请查看下载文件，输入验证码')
    # yan = input()
    yan = vcode

    # 表单
    data = {'loginType':'0',
            'ret':'https://www.qunar.com/?tab=hotel&ex_track=auto_4e0d874a',
            'username':'13429104075',
            'password':'ZLZ5201314',
            'remember':'0',
            'vcode':yan}

    cook = {'QN1':'ezu0rVphsPyccIrMMEYFAg==',
            'QN99': '5421',
            'QunarGlobal': '10.86.213.142_-64f66ec2_1610cdf14ae_-306a|1516339763792',
            'QN205': 'auto_4e0d874a',
            'QN277': 'auto_4e0d874a',
            'csrfToken': 'ak1KR9Qb5xBEKfTqgDYgd7xI9VRhegLm',
            '_i': 'RBTKSL3Z_lRxQ0Mx6q_JzepS-tEx',
            'QN601': '7fe19a954bb039bdfd47b97f0ecc641b',
            'QN269': 'B5E4E831FCD911E79C82FA163EF78B12',
            'QN6': 'auto_4e0d874a',
            'QN163': '0',
            'Hm_lvt_75154a8409c0f82ecd97d538ff0ab3f3': '1516339766',
            'Hm_lpvt_75154a8409c0f82ecd97d538ff0ab3f3': '1516347487',
            'QN48': 'tc_43548e1f78610cbe_1610ce4a244_cfee',
            'QN25': 'e65046cc-f328-474e-8c99-c2eb08d4469b-9f992f90',
            'fid': '40503a36-8628-486c-97ae-0875ab4068cb',
            'QN271': '49ed5517-be7f-4fee-9d9f-05ca5183e9df',
            'JSESSIONID': 'F8CE381A301AD0FE170BCC1DF56E93FB',
            'PHPSESSID': 'nlicnm1pjvob02n9lus3mpdv16',
            'QN219': '"2c5c570a-804b-467b-a004-d90738559a0d-j(Af^gsa"',
            '_vi': 'Wz73h-YNPSx6kvqncVDuc6Vm5bj7XQaj4LKPXrDGMX76i6gpQtr00dBufKc1wmZLfB8nUQN2h8zIJdEdkSfHraV29_t1ULimkhQVW88Wo7aYWezccK99YsXx9 - ns65yp14sR1HEQoM7AgwEZ7A17fSNcJlfPY8yBWp9Eu_v0aByo'
            }
    head = {'Accept':'application/json, text/javascript, */*; q=0.01',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2',
            'Connection': 'keep-alive',
            'Content-Length': '104',
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'Cookie':s,
            'Host': 'user.qunar.com',
            'Referer': 'https://user.qunar.com/passpor…ttps%3A%2F%2Fwww.qunar.com%2F',
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; r…) Gecko/20100101 Firefox/57.0',
            'X-Requested-With': 'XMLHttpRequest'}
    # 登录url
    logurl = 'https://user.qunar.com/passport/loginx.jsp'
    log = sess.post(logurl,cookies=cook,data=data)
    print(log.text)


qunar()