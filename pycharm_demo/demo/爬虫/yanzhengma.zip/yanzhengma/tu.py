import pytesseract
from PIL import Image


# 打开图片
images = Image.open('D:\\demo\\img\\qunar.jpg')
# img = images.resize((180,58))
# 识别图片（将图片转换为string）
vcode = pytesseract.image_to_string(images)
print('asdf',vcode)