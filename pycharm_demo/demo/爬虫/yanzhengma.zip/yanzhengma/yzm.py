import requests
import re
from bs4 import BeautifulSoup
import lxml

def yzm ():
    url = 'http://zjjzzgl.zjsgat.gov.cn:9090'
    dlurl = '/zahlw/login'
    bs = 'http://zjjzzgl.zjsgat.gov.cn:9090/zahlw/login'

    url_p = url + dlurl
    loginHtml = requests.get(bs)
    # print(loginHtml.text)
    soup = BeautifulSoup(loginHtml.text, 'lxml')

    # 下载验证码图片
    spens = soup.find(id = 'img_captcha')
    # img = spens.find('img')
    imgurl = spens.get('src')
    imgurl_p = url + imgurl
    # print(imgurl_p)
    DowImg = requests.get(imgurl_p)
    # 保存路径
    path = 'D:\demo\img\\'+imgurl

    dowpath = open(path,'wb')
    # 将图片以二进制形式写入文件
    dowpath.write(DowImg.content)

    dowpath.close()

    print('请查看下载文件，输入验证码')
    ma = input()
    # 登录
    # 表单拼接
    data = {'welcomeUrl':'zahlw/index',
            'zxtbh':'zahlw',
            'loginType':'zahlw/login',
            'username':'15671278825',
            'password':'lhcxclhh',
            'captcha':ma}
    head = {'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Encoding':'gzip, deflate',
            'Accept-Language':'zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2',
            'Connection':'keep-alive',
            'Content-Length':'112',
            'Content-Type':'application/x-www-form-urlencoded',
            'Cookie':loginHtml.cookies,
            'Host':'zjjzzgl.zjsgat.gov.cn:9090',
            'Referer':'http://zjjzzgl.zjsgat.gov.cn:9090/zahlw/login',
            'Upgrade-Insecure-Requests':'1',
            'User-Agent':'Mozilla/5.0 (Windows NT 6.1; rv:57.0) Gecko/20100101 Firefox/57.0'}

    myhead = {'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Encoding':'gzip, deflate',
            'Accept-Language':'zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2',
            'Connection':'keep-alive',
            'Cookie': loginHtml.cookies,
            'Host': 'zjjzzgl.zjsgat.gov.cn:9090','Upgrade-Insecure-Requests':'1',
            'User-Agent':'Mozilla/5.0 (Windows NT 6.1; rv:57.0) Gecko/20100101 Firefox/57.0'}

    cookies = {'JSESSIONID':'C70CFADC163EFC4A6EA7B18DEA7A2F0C',
               '_version_key':'3301',
               'jcsid':'22c92e16-17aa-4e32-9777-46e77ea98710'}

    log = requests.post(bs,head,data)

    # 我的信息页面
    mytexturl = 'http://zjjzzgl.zjsgat.gov.cn:9090/zahlw/userInfo'
    mytext = requests.post(mytexturl,cookies=log.cookies,allow_redirects=False)
    url302 = mytext.headers['Location']

    print(mytext.headers)

yzm()