# -*- coding: utf-8 -*-
#!/usr/bin/python
import requests
from bs4 import BeautifulSoup
import xlwt
import lxml
import re
import urllib.request

dt = {'lang':'c',
      'url':'http://www.51job.com'
      }
db = {'lang':'c',
      'action':'save',
      'from_domain':'i',
      'loginname':'iospeng@163.com',
      'password':'3999LAOdiDE',
      'verifycode':'',
      'isread':'on'}

header = {'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          'Accept-Encoding':'gzip, deflate, br',
          'Accept-Language':'zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2',
          'Connection':'keep-alive',
          'Content-Length':'97',
          'Content-Type':'application/x-www-form-urlencoded',
          'Cookie':'guid=15155759342015680076; slife=lowbrowser%3Dnot%26%7C%26lastlogindate%3D20180111%26%7C%26; ps=us%3DDzZaMw5oV38HbwxgUSoHMQ08BilbbAdmXGMHKQkyDzpbYlU7VTJRYFYyC25WNlVkU2lUZVNgWnNSJwYZCERTKQ9E%26%7C%26needv%3D0; adv=adsnew%3D0%26%7C%26adsresume%3D1%26%7C%26adsfrom%3Dhttp%253A%252F%252Fbzclk.baidu.com%252Fadrc.php%253Ft%253D06KL00c00fZEOkb0VmkU00uiAsjNk7up00000aaJBdb00000x7CY-H.THYdnyGEm6K85ydEUhkGUhNxuAT0T1Y4PWubnH01nj0snjDsnhf30ZRqwDcdfYmswjTvfWFjPRPAfHD3wRu7fWTsn1D3fYNKf1T0mHdL5iuVmv-b5HnsP1TLrHm4P1RhTZFEuA-b5HDv0ARqpZwYTjCEQLwzmyP-QWRkphqBQhPEUiqYTh7Wui4spZ0Omyw1UMNV5HT3rHc1nzu9pM0qmR9inAPDULunnvf1uZbYnRdgTZuupHNJmWcsI-0zyM-BnW04yydAT7GcNMI-u1YqFh_qnARkPHcYPjFbrAFWrHRsuHR4PhFWPjmkryPhrHKhuhc0mLFW5Hn4rHR4%2526tpl%253Dtpl_10085_16624_12226%2526l%253D1502325280%2526ie%253Dutf-8%2526f%253D8%2526tn%253Dmonline_dg%2526wd%253D51job%2526oq%253D51job%2526rqlang%253Dcn%26%7C%26adsnum%3D789233; _ujz=MTA3NzYwNzQwMA%3D%3D',
          'Host':'login.51job.com',
          'Referer':'https://login.51job.com/login.php?lang=c',
          'Upgrade-Insecure-Requests':'1',
          'User-Agent':'Mozilla/5.0 (Windows NT 6.1; rv:57.0) Gecko/20100101 Firefox/57.0'}

url = 'https://login.51job.com/login.php?lang=c&url=http%3A%2F%2Fwww.51job.com%2F'

rese = requests.session()

xl = rese.post(url,headers=header,data=db)
#设置抓取到的HTML的编码格式，
# xl.encoding = xl.apparent_encoding
# print(xl.text)

#将字符串转换为gb2312编码
str  = '测试'
hasattr(str,'decode')
# print(str)
bs = str.encode('gb2312')
# print(bs)
# 搜素
js ={'fromJs':'1',
     'jobarea':'080200',
     'keyword':bs,
     'keywordtype':'2',
     'lang':'c',
     'stype':'2',
     'postchannel':'0000',
     'fromType':'1',
     'confirmdate':'9'}

url_sou = 'http://search.51job.com/jobsearch/search_result.php'
sousuo = rese.post(url_sou,data=js)
sousuo.encoding = sousuo.apparent_encoding
txt = sousuo.text
# 将抓取到的网页数据放入BeautifulSoup中 用于解析数据
soup = BeautifulSoup(txt, 'lxml')
# 定位到所有class为‘el‘的div
div_one = soup.find(id='resultList')
div_list = div_one.find_all(class_="el")
#删除list中第一个元素，第一个元素是定位错误的元素
del div_list[0]

next_data = {'lang':'c',
             'stype':'1',
             'postchannel':'0000',
             'workyear':'99',
             'cotype':'99',
             'degreefrom':'99',
             'jobterm':'99',
             'companysize':'99',
             'lonlat':'0,0',
             'radius':'-1',
             'ord_field':'0',
             'confirmdate':'9',
             'fromType':'1',
             'dibiaoid':'0',
             'address':'',
             'line':'',
             'specialarea':'00',
             'from':'',
             'welfare':''}

str = "http://search.51job.com/list/080200,000000,0000,00,9,99,%25E6%25B5%258B%25E8%25AF%2595,2,2.html"

# urlDecode编码格式转换为中文
zhong = '%25E6%25B5%258B%25E8%25AF%2595'
# s = urllib.request.quote(zhong)
s = urllib.request.unquote(zhong)
s1 = urllib.request.unquote(s)
# print(s1)
next = rese.get(str)
next.encoding = next.apparent_encoding
div_two = soup.find(id='resultList')
next_list= div_two.find_all(class_="el")
del next_list[0]
# print(next_list)

#链接两个list
div_list.extend(next_list)

# 创建execl
exec = xlwt.Workbook()
# 创建追加数据的sheet
sheet1 = exec.add_sheet(u'sheet1',cell_overwrite_ok=True)
#第一行数据
one= ['招聘岗位名称','招聘信息url','招聘公司名称','招聘公司url','公司所在位置','工资范围','发布时间']
for o in range(0,len(one)):
    sheet1.write(0,o,one[o])

def xieru (div_list,sheet1):
    n = 1
    for i in div_list:
        p = i.find('p')

        a = p.find('a')
        # 招聘信息url
        url = a.get('href')
        # 招聘岗位名称
        name = a.get('title')

        t2 = i.find(class_='t2')
        t2_a = t2.find('a')
        # 招聘公司url
        t2_url = t2_a.get('href')
        # 招聘公司名称
        t2_name = t2_a.get('title')

        t3 = i.find(class_='t3')
        # 公司所在位置
        t3_name = t3.get_text()

        t4 = i.find(class_='t4')
        # 工资范围
        t4_name = t4.get_text()

        t5 = i.find(class_='t5')
        # 发布时间
        t5_name = t5.get_text()

        # 将抓取的数据保存到execl
        sheet1.write(n,0,name)
        sheet1.write(n, 1, url)
        sheet1.write(n, 2, t2_name)
        sheet1.write(n, 3, t2_url)
        sheet1.write(n, 4, t3_name)
        sheet1.write(n, 5, t4_name)
        sheet1.write(n, 6, t5_name)
        n = n+1

    exec.save('zhaoping.xlsx')

xieru(div_list,sheet1)