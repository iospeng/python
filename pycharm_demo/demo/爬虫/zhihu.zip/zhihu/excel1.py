import xlrd # 读取支持库
import xlwt# 写入支持库

def xie():
    # 创建excel
    f = xlwt.Workbook()

    #创建追加数据的sheet
    sheet1 = f.add_sheet(u'sheet1',cell_overwrite_ok=True)
    row1 = ['名称','岗位','公司','工资','李志鹏','测试','xxx','xxxx']
    s = 0
    while s < 2:
        print('dd')
        for j in [0,1,2,3]:
            print('ss')
            if s ==0:
                sheet1.write(s,j,row1[j])
            else:
                sheet1.write(s,j,row1[j+4])
        s = s + 1
    f.save('ss.xlsx')

xie()