
import re
import requests

def test_bd():
    # 知乎表单拼接
    bound = '-----------------------------129042289332643'
    zhdata = []
    zhdata.append('%s' % bound)
    zhdata.append('Content-Disposition: form-data; name="client_id"\r\n')
    zhdata.append('c3cef7c66a1843f8b3a9e6a1e3160e20')

    zhdata.append('%s' % bound)
    zhdata.append('Content-Disposition: form-data; name="grant_type"\r\n')
    zhdata.append('password')

    zhdata.append('%s' % bound)
    zhdata.append('Content-Disposition: form-data; name="timestamp"\r\n')
    zhdata.append('1515396832278')

    zhdata.append('%s' % bound)
    zhdata.append("Content-Disposition: form-data; name='source'"+"\r\n")
    zhdata.append('com.zhihu.web')

    zhdata.append('%s' % bound)
    zhdata.append('Content-Disposition: form-data; name="signature"\r\n')
    zhdata.append('f6fccef0267ed5ae3af71ece222ff5880949457a')

    zhdata.append('%s' % bound)
    zhdata.append('Content-Disposition: form-data; name="username"\r\n')
    zhdata.append('+8615671278825')

    zhdata.append('%s' % bound)
    zhdata.append('Content-Disposition: form-data; name="password"\r\n')
    zhdata.append('123456')

    zhdata.append('%s' % bound)
    zhdata.append('Content-Disposition: form-data; name="lang"\r\n')
    zhdata.append('en')

    zhdata.append('%s' % bound)
    zhdata.append('Content-Disposition: form-data; name="ref_source"\r\n')
    zhdata.append('homepage')

    zhdata.append('%s' % bound)
    zhdata.append('Content-Disposition: form-data; name="utm_source"\r\n')
    zhdata.append('aa')

    zhdata.append('%s' % bound)

    zhihubd = '\r\n'.join(zhdata)

    return zhihubd


def test_header():
    # 知乎请求头
    header = {'Accept':'application/json, text/plain, */*',
              'Accept-Encoding':'gzip, deflate, br',
              'Accept-Language':'zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2',
              'authorization':'oauth c3cef7c66a1843f8b3a9e6a1e3160e20',
              'Connection':'keep-alive',
              'Content-Length':'1275',
              'content-type':'multipart/form-data; boundary=---------------------------129042289332643',
              'Cookie':'q_c1=9d6fdfcd3fc44bb59b2ca910934edd11|1513849089000|1513849089000; _zap=8213a78e-9da4-4118-b5d5-6fffff3afb5a; r_cap_id="N2E3OTEzOTc4MTA0NGIxMzhlNWM4OGNmZmNjY2FiODA=|1515132902|abde742621bdc2800e5f242c6a4d944a2d99ade1"; cap_id="ZTY5ZDg2ZmNlNWUzNGRmMzk2N2VhYzFkMzA2OWVhNzU=|1515132902|b86134c8f3dfd9bf92e79845f025d5ddd1d1873b"; l_cap_id="NTQwZDQ1OTRiNzA3NGU5OTg4ZGY1MzU1Mjg4NzM3ZjI=|1515132902|c60e16933328ea1f2daec695893e83bb1023566d"; capsion_ticket="2|1:0|10:1515396811|14:capsion_ticket|44:NDUzMTlmZWM5ZjE5NDM5MGI0YTk5NTBjYjgzZGMwY2E=|848af7af1e46e8792a6c7198f90151bd9a342d18240437b553bf9bad68350487"; __utma=51854390.1167597524.1515377837.1515377837.1515377837.1; __utmz=51854390.1515377837.1.1.utmcsr=zhihu.com|utmccn=(referral)|utmcmd=referral|utmcct=/; __utmv=51854390.100--|2=registration_date=20160405=1^3=entry_date=20160405=1; aliyungf_tc=AQAAACtg/Ro6TQEAZDyee30wUh0U12yl; d_c0="ADCjbhD-9AyPTiw4f8uFG-popVjnzHFBJig=|1515379594"; _xsrf=10927246-a64c-429c-9e40-aaf166a17949',
              'Host':'www.zhihu.com',
              'origin':'https://www.zhihu.com',
              'Referer':'https://www.zhihu.com/signup?next=%2F',
              'User-Agent':'Mozilla/5.0 (Windows NT 6.1; rv:57.0) Gecko/20100101 Firefox/57.0',
              'x-udid':'ADCjbhD-9AyPTiw4f8uFG-popVjnzHFBJig=',
              'x-xsrftoken':'10927246-a64c-429c-9e40-aaf166a17949'}
    return header


def test_login(db,header):
    # 创建session
    session = requests.session()
    #登录url
    url = 'https://www.zhihu.com/api/v3/oauth/sign_in'
    #登录
    content = session.post(url, headers=header, data=db)
    print(content.text)
    print(db)


test_login(test_bd(),test_header())