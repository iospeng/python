
import requests
import http.cookiejar
from bs4 import BeautifulSoup

session = requests.Session()
data = {'email':'15671278825',
        'password':'lhcxclhh'}

# 请求头
header = {'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          'Accept-Encoding':'gzip, deflate',
          'Accept-Language':'zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2',
          'Connection':'keep-alive',
          'Host':'www.renren.com',
          'Referer':'http://www.renren.com/963034700',
          'Upgrade-Insecure-Requests':'1',
          'User-Agent':'Mozilla/5.0 (Windows NT 6.1; rv:57.0) Gecko/20100101 Firefox/57.0'}
header1 = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; rv:57.0) Gecko/20100101 Firefox/57.0'}
# # 声明一个cookieJar对象实例来保存cookie
# cookie = http.cookiejar()
# # 利用requests

#创建cookiejar对象，并指定保存文件名
session.cookies = http.cookiejar.LWPCookieJar(filename='cookies.txt')

s = session.post('http://www.renren.com/PLogin.do',data=data)
#cookies 保存到本地文件
session.cookies.save()
coo = tuple(s.cookies)
sc = requests.utils.dict_from_cookiejar(session.cookies)
print('sc:',sc)
# print({a.name: a.value for a in s.cookies})
# print(s.headers)

# cookies 转换为 字典
load_cookies = requests.utils.dict_from_cookiejar(coo)
print("||",s.request._cookies)
l = requests.utils.dict_from_cookiejar(s.request._cookies)
print('l||',l)


# s1 = session.get('http://share.renren.com/share/hot/v7',headers=header1,cookies=s.cookies,data=data)
s1 = session.get('http://share.renren.com/share/hot/v7')
print(s1.text)

