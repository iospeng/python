
from selenium import webdriver
import time
import requests
import pickle

def test_login():
    url = 'http://www.renren.com/SysHome.do'
    web_driver = webdriver.Chrome()
    web_driver.get(url)

    web_driver.find_element_by_name('email').send_keys('15671278825')
    web_driver.find_element_by_name('password').send_keys('lhcxclhh')
    web_driver.find_element_by_id('login').click()

    time.sleep(3)
    cookies = web_driver.get_cookies()
    # cookies 转换为 字典
    # diccookies = requests.utils.dict_from_cookiejar(web_driver.get_cookies())
    #关闭浏览器
    # web_driver.close()
    print(cookies)
    # print(diccookies)
    # print({a.name:a.value for a in cookies})

    s = requests.session()
    for cookies in cookies:
        s.cookies.set(cookies['name'],cookies['value'])

    print(s.cookies)
    my = s.post('http://share.renren.com/share/hotlist/v7?t=1')
    print(my.text)

test_login()