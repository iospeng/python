
import re
import requests

def test_cookies():
    cookie = {'q_c1':'9d6fdfcd3fc44bb59b2ca910934edd11|1513849089000|1513849089000',
              '_zap':'8213a78e-9da4-4118-b5d5-6fffff3afb5a',
              'r_cap_id':'"N2E3OTEzOTc4MTA0NGIxMzhlNWM4OGNmZmNjY2FiODA=|1515132902|abde742621bdc2800e5f242c6a4d944a2d99ade1"',
              'cap_id':'"ZTY5ZDg2ZmNlNWUzNGRmMzk2N2VhYzFkMzA2OWVhNzU=|1515132902|b86134c8f3dfd9bf92e79845f025d5ddd1d1873b"',
              'l_cap_id':'"NTQwZDQ1OTRiNzA3NGU5OTg4ZGY1MzU1Mjg4NzM3ZjI=|1515132902|c60e16933328ea1f2daec695893e83bb1023566d"',
              'capsion_ticket':'"2|1:0|10:1515461522|14:capsion_ticket|44:MDgyYWJjZTA2N2EwNDJhOWFmMjhmZTcxMGZhMzhmNDQ=|0ac32c115ada0904616a53d008cd342eebf8cefcba2bb897a8ba480bf5f52dd6"',
              '__utma':'51854390.1167597524.1515377837.1515377837.1515377837.1',
              '__utmz':'51854390.1515377837.1.1.utmcsr=zhihu.com|utmccn=(referral)|utmcmd=referral|utmcct=/',
              '__utmv':'51854390.100--|2=registration_date=20160405=1^3=entry_date=20160405=1',
              'aliyungf_tc':'AQAAACw9fxwsJAQAlTRafBgkI8zRX3zL',
              'd_c0':'"ALAiQJU29gyPTpTrZ0_NlY2d76gIZ2B_Hh4=|1515461519"',
              '_xsrf':' fa9dfee5-8409-4764-835c-c4234f25f388',
              'z_c0':'"2|1:0|10:1515461529|4:z_c0|92:Mi4xMWszVkFnQUFBQUFBc0NKQWxUYjJEQ1lBQUFCZ0FsVk5tV2xCV3dBeDJWMWZtdjNwVF9SY3RvQVdybTcxa2VTYU93|42ef816111ec90b48ab72fdf8942e75fe5dd9c43d64f0c99e6874a0e3e779bde"'}

def test_home_header():
    header = {'Accept':'application/json, text/plain, */*',
              'Accept-Encoding':'gzip, deflate, br',
              'Accept-Language':'zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2',
              'Connection':'keep-alive',
              'Content-Length':'169',
              'content-type':'multipart/form-data; boundary=---------------------------82791776017464',
              'Cookie':'q_c1=9d6fdfcd3fc44bb59b2ca910934edd11|1513849089000|1513849089000; _zap=8213a78e-9da4-4118-b5d5-6fffff3afb5a; r_cap_id="N2E3OTEzOTc4MTA0NGIxMzhlNWM4OGNmZmNjY2FiODA=|1515132902|abde742621bdc2800e5f242c6a4d944a2d99ade1"; cap_id="ZTY5ZDg2ZmNlNWUzNGRmMzk2N2VhYzFkMzA2OWVhNzU=|1515132902|b86134c8f3dfd9bf92e79845f025d5ddd1d1873b"; l_cap_id="NTQwZDQ1OTRiNzA3NGU5OTg4ZGY1MzU1Mjg4NzM3ZjI=|1515132902|c60e16933328ea1f2daec695893e83bb1023566d"; capsion_ticket="2|1:0|10:1515461522|14:capsion_ticket|44:MDgyYWJjZTA2N2EwNDJhOWFmMjhmZTcxMGZhMzhmNDQ=|0ac32c115ada0904616a53d008cd342eebf8cefcba2bb897a8ba480bf5f52dd6"; __utma=51854390.1167597524.1515377837.1515377837.1515377837.1; __utmz=51854390.1515377837.1.1.utmcsr=zhihu.com|utmccn=(referral)|utmcmd=referral|utmcct=/; __utmv=51854390.100--|2=registration_date=20160405=1^3=entry_date=20160405=1; aliyungf_tc=AQAAACw9fxwsJAQAlTRafBgkI8zRX3zL; d_c0="ALAiQJU29gyPTpTrZ0_NlY2d76gIZ2B_Hh4=|1515461519"; _xsrf=fa9dfee5-8409-4764-835c-c4234f25f388; z_c0="2|1:0|10:1515461529|4:z_c0|92:Mi4xMWszVkFnQUFBQUFBc0NKQWxUYjJEQ1lBQUFCZ0FsVk5tV2xCV3dBeDJWMWZtdjNwVF9SY3RvQVdybTcxa2VTYU93|42ef816111ec90b48ab72fdf8942e75fe5dd9c43d64f0c99e6874a0e3e779bde',
              'Host':'www.zhihu.com',
              'origin':'https://www.zhihu.com',
              'Referer':'https://www.zhihu.com',
              'User-Agent':'Mozilla/5.0 (Windows NT 6.1; rv:57.0) Gecko/20100101 Firefox/57.0'}
    return header

def test_home(header,cookies):
    url = 'https://www.zhihu.com'
    home_text = requests.post(url,cookies,header)
    print(home_text.text)

test_home(test_home_header(),test_cookies())