# coding utf-8

import time
import unittest
import logging
from selenium import webdriver
from Feifa_pacage.LY_Login import Logins
from Feifa_pacage.loggers import Log

driver_obj = Logins()
obj_log = Log()


class ShouYe(unittest.TestCase):

    def test_Control(self):
        """布控核查"""
        time.sleep(3)
        try:
            driver_obj.driver.find_element_by_xpath('/html/body/div/div[1]/div[1]/div/ul/li[2]/div/a/span[2]').click()
        except:
            obj_log.write_error('定位布控核查按钮失败')
